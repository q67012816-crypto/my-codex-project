Cora 十次完整基线结果导出
先阅读 report.pdf 或 REPORT.md；表格见 results.xlsx。
预测 CSV 含全部节点及其 train/validation/test 划分，论文指标仅使用测试节点。
这是当前实现基线，尚未成功复现论文性能；差异详见报告。
本包不含模型权重；权重另见 cora-model-checkpoints.zip。
原始实验结果未改写。
