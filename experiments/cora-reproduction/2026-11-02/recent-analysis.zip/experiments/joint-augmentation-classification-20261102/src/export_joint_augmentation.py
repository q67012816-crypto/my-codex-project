import ast
import csv
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/joint-augmentation-classification-20261102-01')
OUT=WS/'outputs/joint-augmentation-classification-20261102'
assert not OUT.exists()
for path in ROOT.glob('*.exit.json'):assert json.loads(path.read_text())['exit_code']==0
summary=json.loads((ROOT/'full-summary.json').read_text());decision=json.loads((ROOT/'adoption-decision.json').read_text())
audits=[]
for item in summary['results']:
    values=np.load(ROOT/'full'/item['condition']/'validation-only.npz')
    truth,prediction,degree=values['labels'],values['predictions'],values['degree']
    q=np.percentile(degree,[20,80]);low=degree<=q[0];high=degree>q[1];sp=[];eo=[];recalls=[]
    for c in np.unique(truth):
        a=low&(truth==c);b=high&(truth==c);assert a.any() and b.any()
        lo=float(np.mean(prediction[a]==c));hi=float(np.mean(prediction[b]==c));recalls.append([lo,hi])
        eo.append(abs(lo-hi));sp.append(abs(np.mean(prediction[low]==c)-np.mean(prediction[high]==c)))
    audit={'condition':item['condition'],'accuracy':100*float(np.mean(prediction==truth)),
           'SP':100*float(np.mean(sp)),'EO':100*float(np.mean(eo)),
           'macro_worst_group_recall':100*float(np.min(recalls,axis=1).mean()),'minimum_class_group_recall':100*float(np.min(recalls))}
    for key in ('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall'):
        assert abs(audit[key]-item['selected'][key])<1e-10
    audits.append(audit)
old=np.load(WS/'outputs/loss-calibration-20261102/full/seed-00/baseline/validation-only.npz')
now=np.load(ROOT/'full/frozen/validation-only.npz')
assert all(np.array_equal(old[k],now[k]) for k in ('validation_ids','labels','degree','predictions'))
shutil.copytree(ROOT,OUT)
for name in ('replay_joint_augmentation.py','export_joint_augmentation.py'):
    shutil.copy2(WS/'work'/name,OUT/'src'/name)
for name in ('dependency-manifest.json','environment.json'):
    shutil.copy2(WS/'outputs/loss-calibration-20261102'/name,OUT/name)
for path in (OUT/'src').glob('*.py'):ast.parse(path.read_text())
(OUT/'independent-validation-audit.json').write_text(json.dumps({'frozen_control_matches_previous_predictions':True,'results':audits},indent=2))
with (OUT/'validation-comparison.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(audits[0]));writer.writeheader();writer.writerows(audits)
for item in summary['results']:
    v=np.load(OUT/'full'/item['condition']/'validation-only.npz')
    with (OUT/f"validation-predictions-{item['condition']}.csv").open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['node_id','label','prediction','original_degree'])
        writer.writerows(zip(v['validation_ids'],v['labels'],v['predictions'],v['degree']))
table='\n'.join(f"| {v['condition']} | {v['accuracy']:.2f} | {v['SP']:.2f} | {v['EO']:.2f} | {v['macro_worst_group_recall']:.2f} | {v['minimum_class_group_recall']:.2f} |" for v in audits)
base,new=audits
conclusion='联合训练通过了种子0预设门槛，仍须跨种子确认，不能直接宣称复现成功。' if decision['adopt'] else '联合训练未通过种子0预设门槛，未替换已保存的基线模型。'
report=f'''# 后续步骤：分类阶段是否联合训练增强器

{conclusion}

## 为什么查这一处

上一项PCGrad试验已完成3种子50轮和种子0完整训练：原权重/冻结增强器的种子0验证准确率83.55%、EO9.92；PCGrad预训练后同样冻结增强器，准确率82.44%、EO8.33。EO下降15.95%，但准确率下降1.11个百分点，超过事前0.5个百分点上限，因此没有扩展或叠加其他方法。

随后发现一个具体的流程差异：最近两项隔离预训练影响的试验在分类阶段冻结了增强网络，而官方提交948f254的Transformer_class将全部预训练模型参数设为requires_grad=True。证据原文保存在evidence/official-models-948f254.py。公开GCN并未进入可学习概率路径，因此这只能核实“参数是否允许微调”的公开行为，不能证明作者实际可学习增强采用的完整联合训练方法。

本轮复用原权重0.5S+0.5F+A训练500轮的同一预训练检查点，只比较分类时冻结或解冻增强模块。没有再次预训练，没有混入PCGrad或标定权重，也没有把未公开实现猜测当作已证实错误。

## 运行与验证

先执行两条件各2轮短流程：冻结条件增强网络无梯度、参数零变化；联合条件8个参数张量均有有限非零梯度、优化器实际更新。短流程只检验流程，低准确率时得到的较小EO不计为性能成果。

随后两条件从相同预训练状态和相同新分类头重新训练，最多500轮、耐心100，Adam lr1e-4/weight_decay1e-5，公共行为的概率输入CE，初始化种子100、训练随机种子810000、验证固定采样种子100000。只按验证准确率严格改善选权重，较早轮次优先；不按EO选轮次。

两阶段进程退出0；源预训练检查点指纹未变；两个分类检查点重载后的验证预测一致。冻结条件的验证节点ID、标签、度数、预测与上次基线逐项完全相同，因此这次配对没有重新换一个更容易比较的基线。

## 种子0验证结果

| 条件 | 准确率%↑ | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---:|---:|---:|---:|---:|
{table}

联合减冻结：准确率{new['accuracy']-base['accuracy']:+.2f}个百分点，SP{new['SP']-base['SP']:+.2f}个百分点，EO{new['EO']-base['EO']:+.2f}个百分点。

预先登记的采用门槛：EO相对改善至少10%，准确率下降不超过0.5个百分点，按类最差组召回均值和全部类组最小召回均不下降。当前是一个种子的验证诊断，不能替代论文10次测试均值，也不能与测试EO4.26直接比较。本轮未计算测试指标。

EO和SP从保存的验证预测独立复算通过。分组仍是原始简单图r1度数，在验证541个节点内取20/80百分位：低组≤2、高组>5，分别204/80个节点；逐类绝对召回差取7类宏平均，没有缺失类别。详细条件召回见full/*/result.json，逐轮变化见history.jsonl。

## 下一步的边界

优先对齐明确可核实的训练行为、增强概率的参数化和损失输入/归约。静态权重与PCGrad均已有结果，不继续把它们叠成一个无法解释的配置。若某个候选通过验证门槛，再固定配置做种子0/1/2确认，最终才开展论文要求的10次统计。当前仍未复现论文EO，不保证未验证的修改能达到4.26。

PCGrad的独立实验见同级pcgrad-augmentation-20261102/report.md，投影方法依据[原论文](https://proceedings.neurips.cc/paper/2020/hash/3fe78a8acf5fda99de95303940a2420c-Abstract.html)。本报告联合训练条件没有使用PCGrad。

## 交付与复跑

本目录包含协议、源码、官方源码证据、原始预训练检查点、两阶段日志/退出码、分类权重、验证NPZ/CSV、独立复算与依赖指纹。所有旧代码、模型、数据和结果保留。执行replay.ps1会在D:/cgt-experiment新建时间戳目录，复用Ubuntu-D的既有cgt环境，检查依赖后重复短流程和种子0对照；不安装、不下载、不覆盖旧结果。CUDA独立重训可能有细小数值差异，本次同一检查点恢复预测一致。
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
ps1='''$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/replay_joint_augmentation.py').Replace('\\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath
if ($LASTEXITCODE -ne 0) { throw "Replay failed, exit code $LASTEXITCODE" }
'''
(OUT/'replay.ps1').write_text(ps1)
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'files':len(manifest)+1,'adopt':decision['adopt'],'results':audits},indent=2),flush=True)
