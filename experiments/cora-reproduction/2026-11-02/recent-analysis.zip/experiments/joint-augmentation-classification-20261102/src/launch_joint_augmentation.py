import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/joint-augmentation-classification-20261102-01')
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir();(ROOT/'evidence').mkdir()
previous=WS/'outputs/loss-calibration-20261102'
for name in ('gated_models.py','loss_calibration_runtime.py'):
    shutil.copy2(previous/'src'/name,ROOT/'src'/name)
for name in ('run_joint_augmentation.py','launch_joint_augmentation.py'):
    shutil.copy2(WS/'work'/name,ROOT/'src'/name)
shutil.copy2(previous/'full/seed-00/baseline/pretrained.pt',ROOT/'source-pretrained.pt')
official=subprocess.check_output(['git','-C','/root/cgt/repo','show','HEAD:models.py'],text=True)
(ROOT/'evidence/official-models-948f254.py').write_text(official)
assert 'p.requires_grad = True' in official
protocol={'date':'2026-11-02 Asia/Seoul','only_changed_factor':'augmentation parameters trainable during supervised classification',
    'motivation':'recent isolated pretraining pilots froze augmentation during classification; public Transformer_class sets all pretrained model parameters requires_grad True',
    'scope':'alignment of parameter-freezing behavior on OUR reconstructed trainable augmentation, not a claim to recover hidden original augmentation implementation',
    'source_pretrained_sha256':hashlib.sha256((ROOT/'source-pretrained.pt').read_bytes()).hexdigest(),
    'architecture_sha256':hashlib.sha256((ROOT/'src/gated_models.py').read_bytes()).hexdigest(),
    'pretraining':'reuse original-weight baseline500epoch checkpoint, no new pretraining',
    'smoke_epochs':2,'full_max_epochs':500,'patience':100,'lr':1e-4,'weight_decay':1e-5,
    'classifier_initialization_seed':100,'training_rng_seed':810000,'evaluation_rng_seed':100000,
    'selection':'strict validation accuracy, earlier ties; no EO selection',
    'classification_loss':'same public probability-input CE in both arms',
    'validation_only':True,'test_metrics_computed':False,
    'adoption_gate':'EO relative improvement>=10%, accuracy drop<=0.5pp, macro worst-group recall and minimum class-group recall nondecreasing',
    'not_changed':['model architecture','sampler bounds','classification loss','split','evaluation rules','pretraining weights','PCGrad']}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
for stage,flags in [('smoke',['--smoke']),('full',[])]:
    command=[sys.executable,'-u',str(ROOT/'src/run_joint_augmentation.py'),*flags];tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
        'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-5000:]);sys.exit(code)
base,new=[v['selected'] for v in json.loads((ROOT/'full-summary.json').read_text())['results']]
adopt=new['EO']<=.9*base['EO'] and new['accuracy']>=base['accuracy']-.5 and new['macro_worst_group_recall']>=base['macro_worst_group_recall']-1e-10 and new['minimum_class_group_recall']>=base['minimum_class_group_recall']-1e-10
(ROOT/'adoption-decision.json').write_text(json.dumps({'adopt':adopt,'base':base,'candidate':new,'test_metrics_computed':False},indent=2))
print('ADOPTION_GATE '+str(adopt),flush=True)
