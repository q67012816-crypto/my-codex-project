import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ARTIFACT=Path(__file__).resolve().parent.parent
for item in json.loads((ARTIFACT/'dependency-manifest.json').read_text()):
    path=Path(item['path']);assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],str(path)
ROOT=Path('/mnt/d/cgt-experiment')/('joint-augmentation-replay-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir()
for name in ('gated_models.py','loss_calibration_runtime.py','run_joint_augmentation.py'):
    shutil.copy2(ARTIFACT/'src'/name,ROOT/'src'/name)
for name in ('protocol.json','source-pretrained.pt'):shutil.copy2(ARTIFACT/name,ROOT/name)
print('NEW_EXPERIMENT_DIRECTORY '+str(ROOT),flush=True)
for stage,flags in [('smoke',['--smoke']),('full',[])]:
    command=[sys.executable,'-u',str(ROOT/'src/run_joint_augmentation.py'),*flags];tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
            'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-5000:]);sys.exit(code)
base,new=[v['selected'] for v in json.loads((ROOT/'full-summary.json').read_text())['results']]
adopt=new['EO']<=.9*base['EO'] and new['accuracy']>=base['accuracy']-.5 and new['macro_worst_group_recall']>=base['macro_worst_group_recall']-1e-10 and new['minimum_class_group_recall']>=base['minimum_class_group_recall']-1e-10
(ROOT/'adoption-decision.json').write_text(json.dumps({'adopt':adopt,'base':base,'candidate':new,'test_metrics_computed':False},indent=2))
print('ADOPTION_GATE '+str(adopt),flush=True)
