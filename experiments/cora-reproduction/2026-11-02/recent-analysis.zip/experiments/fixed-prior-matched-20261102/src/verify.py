import argparse,json,torch,numpy as np
import loss_calibration_runtime as rt
p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=0);p.add_argument('--condition',choices=['fixed','residual'],default='fixed');a=p.parse_args()
d=rt.ROOT/f'full/seed-{a.seed:02d}/{a.condition}'
c=torch.load(d/'classifier-best.pt',map_location='cpu');m=rt.training.Classifier(rt.new_encoder()).to(rt.training.DEVICE)
m.load_state_dict(c['state_dict']);m.encoder.gcn.learn_augmentation=a.condition=='residual'
pred=rt.training.evaluate(m,rt.active,c['best_epoch'],100000+a.seed).argmax(1).cpu().numpy();v=np.load(d/'validation-only.npz')
assert np.array_equal(pred[v['validation_ids']],v['predictions'])
print(json.dumps({'seed':a.seed,'condition':a.condition,'validation_predictions_identical':True,'test_metrics_computed':False}))
