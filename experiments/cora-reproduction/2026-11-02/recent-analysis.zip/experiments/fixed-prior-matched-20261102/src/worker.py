import json,sys,time
import numpy as np
import torch
import loss_calibration_runtime as rt
import classifier as cl
ROOT=rt.ROOT;training=rt.training;MODE=sys.argv[1];cl.MODE=MODE

def new(seed,condition):
    training.seed_all(seed);model=rt.new_encoder()
    model.load_state_dict(torch.load(ROOT/f'initial/seed-{seed:02d}.pt',map_location='cpu')['state_dict'])
    model.gcn.learn_augmentation=condition=='residual'
    return model

def equivalence(seed):
    values=[]
    for condition in ('fixed','residual'):
        model=new(seed,condition);model.train();training.seed_all(900000+seed)
        with torch.no_grad():
            h,x,a=rt.forward_encoder(model)
            probability=model.gcn.last_probabilities.detach().cpu();pairs=model.gcn.anchor_pairs
            expected=(.8*rt.adj+.2*rt.cache['B'])[pairs[0],pairs[1]].cpu()
            assert torch.allclose(probability,expected,atol=1e-7,rtol=1e-6)
            values.append((probability,a.cpu(),h.cpu(),torch.cuda.get_rng_state().cpu()))
    errors=[float((a-b).abs().max()) for a,b in zip(values[0][:3],values[1][:3])]
    assert max(errors)<1e-6 and torch.equal(values[0][3],values[1][3])
    return {'seed':seed,'max_errors_probability_sample_embedding':errors,'cuda_rng_states_equal':True}

def pretrain(seed,condition,epochs):
    dest=ROOT/'pretraining'/f'seed-{seed:02d}'/condition;dest.mkdir(parents=True,exist_ok=False)
    model=new(seed,condition);training.seed_all(900000+seed)
    optimizer=torch.optim.Adam(model.parameters(),lr=1e-4,weight_decay=1e-5)
    initial={n:p.detach().clone() for n,p in model.gcn.named_parameters()}
    best=float('inf');best_epoch=0;state=None;start=time.monotonic()
    with (dest/'history.jsonl').open('x') as f:
        for epoch in range(1,epochs+1):
            model.train();optimizer.zero_grad(set_to_none=True)
            h,x,a=rt.forward_encoder(model,epoch);terms=rt.loss_terms(model,h,x)
            total=.5*terms['S']+.5*terms['F']+terms['A'];assert torch.isfinite(total)
            row={'epoch':epoch,'total':float(total.detach()),'raw_losses':{k:float(v.detach()) for k,v in terms.items()}}
            if row['total']<best:best=row['total'];best_epoch=epoch;state=training.cpu_state(model)
            total.backward()
            if epoch==1:
                assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
                shared_before=model.embedding_h.weight.detach().clone()
                assert model.embedding_h.weight.grad.norm()>0
                grads={n:float(p.grad.norm()) if p.grad is not None else None for n,p in model.gcn.named_parameters()}
                if condition=='fixed':assert all(v is None for v in grads.values())
                else:assert all(v is not None and v>0 for v in grads.values())
            optimizer.step()
            if epoch==1:assert not torch.equal(shared_before,model.embedding_h.weight.detach())
            f.write(json.dumps(row)+'\n');f.flush()
            if epoch==1 or epoch%50==0:print('SSL '+json.dumps({'seed':seed,'condition':condition,**row}),flush=True)
    deltas={n:float((p.detach()-initial[n]).abs().max()) for n,p in model.gcn.named_parameters()}
    assert all(torch.isfinite(p).all() for p in model.parameters())
    assert all(v==0 for v in deltas.values()) if condition=='fixed' else all(v>0 for v in deltas.values())
    torch.save({'state_dict':state,'best_epoch':best_epoch,'config':{'condition':condition,'seed':seed,'learn_augmentation':condition=='residual'}},dest/'pretrained.pt')
    result={'seed':seed,'condition':condition,'best_epoch':best_epoch,'epochs':epochs,'first_sampler_gradient_norms':grads,
        'sampler_parameter_max_changes':deltas,'shared_parameter_update_verified':True,'finite':True,'elapsed_seconds':time.monotonic()-start}
    training.write_json(dest/'result.json',result)
    return result

equiv=[equivalence(s) for s in (0,1,2)] if MODE=='short' else []
if MODE=='short':training.write_json(ROOT/'equivalence.json',equiv)
results=[];ssl=[]
for seed in (0,1,2):
    for condition in ('fixed','residual'):
        # Stage-specific roots preserve the short checkpoints when beginning full runs.
        prior=ROOT/'pretraining'/f'seed-{seed:02d}'/condition
        if prior.exists():
            archived=ROOT/'short-pretraining'/f'seed-{seed:02d}'/condition;archived.parent.mkdir(parents=True,exist_ok=True)
            assert not archived.exists();prior.rename(archived)
        ssl.append(pretrain(seed,condition,50 if MODE=='short' else 500));torch.cuda.empty_cache()
        results.append(cl.run(seed,condition,False));torch.cuda.empty_cache()
for seed in (0,1,2):
    a,b=[r for r in results if r['seed']==seed]
    assert a['head_initial_sha256']==b['head_initial_sha256']
training.write_json(ROOT/(MODE+'-summary.json'),{'pass':True,'results':results,'pretraining':ssl,'test_metrics_computed':False})
print('STAGE_COMPLETE '+MODE,flush=True)
