import json,shutil,subprocess,sys,time,difflib
from pathlib import Path
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/fixed-prior-matched-20261102-01')
OLD=WS/'outputs/joint-augmentation-confirmation-20261102'
CAL=WS/'outputs/loss-calibration-20261102'
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir();(ROOT/'initial').mkdir()
for n in ('gated_models.py','loss_calibration_runtime.py'):shutil.copy2(OLD/'src'/n,ROOT/'src'/n)
for s in (0,1,2):shutil.copy2(CAL/f'calibration/initial-seed-{s:02d}.pt',ROOT/f'initial/seed-{s:02d}.pt')
protocol={'only_factor':'augmentation probability fixed prior versus bounded learned GCN residual',
 'fixed':'sigmoid(logit(.8*A+.2*B)), no learned residual','residual':'same prior plus tanh(GCN score-initial score) in logit space',
 'B':'existing verified degree-weighted same-community cumulative-neighborhood cache, unchanged',
 'seeds':[0,1,2],'short_pretrain_epochs':50,'short_classification_epochs':2,
 'full_pretrain_epochs':500,'full_classification_max_epochs':500,'patience':100,
 'SSL':'.5*S+.5*F+A; same exact mean definitions as archived runtime',
 'classification':'public probability-input CE; no additional BCE or PCGrad',
 'optimizer':'Adam lr1e-4 weight_decay1e-5','selection':'SSL minimum training objective, classification strict validation accuracy, earlier ties',
 'training_streams':'pretrain900000+seed; classifier init100+seed; classifier810000+seed; evaluation100000+seed',
 'short_gate':'equal probabilities, hard samples and embeddings before training; finite actual shared-parameter updates; fixed sampler unchanged, residual sampler updated; reload validation predictions equal',
 'scope':'controlled diagnosis of additional reconstruction choice, not confirmed recovery of author training',
 'test_metrics_computed':False,'no_test_based_selection':True,'no_ten_run_batch':True}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
source=(OLD/'src/run_joint_confirmation.py').read_text().split("if __name__=='__main__':")[0]
original=source
replacements=[("stage='smoke' if smoke else 'full'","stage=MODE"),
 ("trainable=condition=='joint'","trainable=condition=='residual'"),
 ("'max_epochs':2 if smoke else 500","'max_epochs':2 if MODE=='short' else 500"),
 ("'baseline/pretrained.pt'","condition/'pretrained.pt'")]
for a,b in replacements:assert a in source,a;source=source.replace(a,b)
source=source.replace('model.encoder.load_state_dict(',"model.encoder.gcn.learn_augmentation=condition=='residual'\n    model.encoder.load_state_dict(")
source=source.replace('assert model.encoder.gcn.learn_augmentation',"assert model.encoder.gcn.learn_augmentation==trainable")
source=source.replace('restored.load_state_dict(',"restored.encoder.gcn.learn_augmentation=condition=='residual'\n    restored.load_state_dict(")
(ROOT/'src/classifier.py').write_text(source)
(ROOT/'src/classifier-original.py').write_text(original)
(ROOT/'classifier-change.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True))))
shutil.copy2(WS/'work/fixed_prior_worker.py',ROOT/'src/worker.py')
shutil.copy2(Path(__file__),ROOT/'src/start_fixed_prior_matched.py')
def execute(stage):
    command=[sys.executable,'-u',str(ROOT/'src/worker.py'),stage];start=time.monotonic()
    with (ROOT/(stage+'.log')).open('x') as f:
        try:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=1200).returncode
        except subprocess.TimeoutExpired:code=124
    record={'exit_code':code,'elapsed_seconds':time.monotonic()-start,'command':command}
    (ROOT/(stage+'.exit.json')).write_text(json.dumps(record,indent=2));print(stage+' '+json.dumps(record),flush=True)
    if code:
        print((ROOT/(stage+'.log')).read_text()[-4500:]);sys.exit(code)
execute('short')
if json.loads((ROOT/'short-summary.json').read_text())['pass']:execute('full')
print('COMPLETE',flush=True)
