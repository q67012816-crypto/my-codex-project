import ast,csv,hashlib,json,shutil
from pathlib import Path
import numpy as np
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/fixed-prior-matched-20261102-01');OUT=WS/'outputs/fixed-prior-matched-20261102'
assert not OUT.exists()
for p in ROOT.glob('*.exit.json'):assert json.loads(p.read_text())['exit_code']==0
summary=json.loads((ROOT/'full-summary.json').read_text());rows=[]
for r in summary['results']:
    d=ROOT/f"full/seed-{r['seed']:02d}/{r['condition']}";v=np.load(d/'validation-only.npz')
    y,p,degree=v['labels'],v['predictions'],v['degree'];q=np.percentile(degree,[20,80]);lo=degree<=q[0];hi=degree>q[1]
    recall=np.array([[np.mean(p[lo&(y==c)]==c),np.mean(p[hi&(y==c)]==c)] for c in np.unique(y)])
    metrics={'accuracy':100*float(np.mean(p==y)),'EO':100*float(np.abs(recall[:,0]-recall[:,1]).mean()),
        'SP':100*float(np.mean([abs(np.mean(p[lo]==c)-np.mean(p[hi]==c)) for c in np.unique(y)])),
        'macro_worst_group_recall':100*float(recall.min(1).mean()),'minimum_class_group_recall':100*float(recall.min())}
    assert all(abs(value-r['selected'][k])<1e-10 for k,value in metrics.items())
    rows.append({'seed':r['seed'],'condition':r['condition'],**metrics,'best_epoch':r['best_epoch']})
means={condition:{k:float(np.mean([r[k] for r in rows if r['condition']==condition])) for k in ('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall')} for condition in ('fixed','residual')}
shutil.copytree(ROOT,OUT)
shutil.copy2(Path(__file__),OUT/'src/export_fixed_prior_matched.py')
for n in ('environment.json','dependency-manifest.json'):shutil.copy2(WS/'outputs/joint-augmentation-confirmation-20261102'/n,OUT/n)
(OUT/'independent-audit.json').write_text(json.dumps({'rows':rows,'means':means,'test_metrics_computed':False},indent=2))
with (OUT/'validation-comparison.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for r in rows:
    d=OUT/f"full/seed-{r['seed']:02d}/{r['condition']}";v=np.load(d/'validation-only.npz')
    with (d/'validation-predictions.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['node_id','label','prediction','original_degree']);writer.writerows(zip(v['validation_ids'],v['labels'],v['predictions'],v['degree']))
verifier='''import argparse,json,torch,numpy as np
import loss_calibration_runtime as rt
p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=0);p.add_argument('--condition',choices=['fixed','residual'],default='fixed');a=p.parse_args()
d=rt.ROOT/f'full/seed-{a.seed:02d}/{a.condition}'
c=torch.load(d/'classifier-best.pt',map_location='cpu');m=rt.training.Classifier(rt.new_encoder()).to(rt.training.DEVICE)
m.load_state_dict(c['state_dict']);m.encoder.gcn.learn_augmentation=a.condition=='residual'
pred=rt.training.evaluate(m,rt.active,c['best_epoch'],100000+a.seed).argmax(1).cpu().numpy();v=np.load(d/'validation-only.npz')
assert np.array_equal(pred[v['validation_ids']],v['predictions'])
print(json.dumps({'seed':a.seed,'condition':a.condition,'validation_predictions_identical':True,'test_metrics_computed':False}))
'''
(OUT/'src/verify.py').write_text(verifier)
launcher='''param([ValidateSet(0,1,2)][int]$Seed=0,[ValidateSet('fixed','residual')][string]$Condition='fixed')
$ErrorActionPreference='Stop'
$scriptPath=(Join-Path $PSScriptRoot 'src/verify.py').Replace('\\\\','/')
$convertedPath=& wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath=$convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root --exec /usr/bin/env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath --seed $Seed --condition $Condition
if ($LASTEXITCODE -ne 0) { throw 'Prediction verification failed' }
'''
(OUT/'verify.ps1').write_text(launcher)
for p in (OUT/'src').glob('*.py'):ast.parse(p.read_text())
table='\n'.join(f"| {r['seed']} | {r['condition']} | {r['accuracy']:.2f} | {r['SP']:.2f} | {r['EO']:.2f} | {r['macro_worst_group_recall']:.2f} | {r['minimum_class_group_recall']:.2f} |" for r in rows)
mean_table='\n'.join(f"| {c} | {r['accuracy']:.2f} | {r['SP']:.2f} | {r['EO']:.2f} | {r['macro_worst_group_recall']:.2f} | {r['minimum_class_group_recall']:.2f} |" for c,r in means.items())
report=f'''# 固定概率与GCN残差增强的匹配对照

完成三种子、两条件各50轮预训练及2轮分类短流程，然后各500轮预训练和最多500轮分类。所有阶段退出0，历史模型未覆盖。没有新测试评分或10次长批量。

唯一控制变量是概率中是否包含我们添加的GCN/tanh/anchor残差。fixed使用p=0.8A+0.2B（B为已核验的度权重D缓存）；residual在其logit上增加tanh(GCN点积分数−初始分数)。两者使用同一候选支持、初始编码器权重、分类头、划分、逐候选采样顺序、随机种子、优化器和预算。

在训练前，同概率下两者的概率、硬采样图和编码器输出最大差均为0，CUDA随机数状态也完全一致，3个初始化均通过，见equivalence.json。固定条件增强参数没有梯度/变化，残差条件增强参数有有限非零梯度与实际更新，共享编码器均实际更新。每个分类检查点重载后验证预测一致；固定条件恢复时明确设置learn_augmentation=False，这一Python标志不由state_dict自动保存。

## 验证结果

| 种子 | 条件 | 准确率% | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---|---:|---:|---:|---:|---:|
{table}

| 三种子均值 | 准确率% | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---:|---:|---:|---:|---:|
{mean_table}

fixed减residual：准确率{means['fixed']['accuracy']-means['residual']['accuracy']:+.2f}个百分点，SP{means['fixed']['SP']-means['residual']['SP']:+.2f}个百分点，EO{means['fixed']['EO']-means['residual']['EO']:+.2f}个百分点。只能解释本次额外残差开关的影响，不能把验证指标当作论文测试指标。

## 规则与边界

SSL保持0.5S+0.5F+A，均值归约与上一轮完全相同；分类保持公开概率输入CE，无新增BCE、PCGrad或公平性约束。Adam lr1e-4/weight_decay1e-5。预训练按训练SSL目标最低保存更新前权重；分类按验证准确率严格提高选轮次，耐心100，较早轮次优先，没有按EO选轮次。

公平性使用原简单图r1度数，在验证划分内20/80百分位分组，逐类绝对召回差宏平均。独立从保存预测重算准确率、SP、EO和两项较弱组召回，与原报告一致。

固定概率公式并未补足作者“可学习”变换的未明确实现。本对照不是作者原模型的唯一确定复现，未恢复论文全部损失语义。先前主配置测试86.20%/SP3.12/EO12.02属于另一套已归档实验，不与本次不同采样实现/分类头的验证结果拼表作因果比较。当前不能声称复现了论文测试EO4.26。

训练代码、修改前分类代码与diff、协议、每轮日志、初始权重、预训练和分类检查点、逐节点验证预测均保存在本目录。src/verify.py可用记录的WSL cgt环境加载指定seed/condition并复核验证预测，不计算测试指标。旧数据、缓存和环境保持复用。
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
manifest=[{'path':str(p.relative_to(OUT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'validation_means':means,'validation_rows':rows},indent=2),flush=True)
