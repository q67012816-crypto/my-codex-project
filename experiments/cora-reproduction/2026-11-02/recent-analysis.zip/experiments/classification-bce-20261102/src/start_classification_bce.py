import json,shutil,subprocess,sys,time,hashlib
from pathlib import Path
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
OLD=WS/'outputs/joint-augmentation-confirmation-20261102'
ROOT=Path('/mnt/d/cgt-experiment/classification-bce-20261102-01')
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir()
for n in ('gated_models.py','loss_calibration_runtime.py'):shutil.copy2(OLD/'src'/n,ROOT/'src'/n)
for seed in (0,1,2):
    dest=ROOT/f'pretraining/seed-{seed:02d}/baseline';dest.mkdir(parents=True)
    shutil.copy2(OLD/f'pretraining/seed-{seed:02d}/baseline/pretrained.pt',dest/'pretrained.pt')
protocol={'only_change':'classification CE versus CE+A; both augmentation networks trainable',
 'A':'2*upper candidate BCEWithLogits(logits,original edge).sum/(N*N), coefficient1',
 'seeds':[0,1,2],'short_epochs':50,'full_epochs':500,'patience':100,'lr':1e-4,'weight_decay':1e-5,
 'selection':'validation accuracy only, earlier ties','test_based_tuning':False,
 'short_gate':'finite updates; mean terminal saturation and raw A lower under CE+A than CE; no saturated increase in any seed',
 'validation_gate':'mean EO improves10%; each accuracy drop<=0.5pp; mean worst-group and minimum recall nondecreasing',
 'scope':'engineering experiment, not verified author implementation'}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
source=(OLD/'src/run_joint_confirmation.py').read_text().split("if __name__=='__main__':")[0]
original=source
def change(a,b):
    global source
    assert a in source,a
    source=source.replace(a,b)
change("stage='smoke' if smoke else 'full'","stage=MODE")
change("trainable=condition=='joint'","trainable=True")
change("'max_epochs':2 if smoke else 500","'max_epochs':50 if MODE=='short' else 500")
change("loss=F.cross_entropy(logits.softmax(1)[train],labels[train]);assert torch.isfinite(loss)","""ce=F.cross_entropy(logits.softmax(1)[train],labels[train])
            sampler=model.encoder.gcn
            augmentation=2*F.binary_cross_entropy_with_logits(sampler.last_logits,sampler.last_targets,reduction='sum')/(rt.N*rt.N)
            loss=ce+augmentation if condition=='bce' else ce
            assert torch.isfinite(loss)
            with torch.no_grad():
                pairs=sampler.anchor_pairs;prob=sampler.last_probabilities.detach();target=sampler.last_targets.bool()
                prior=(.2*rt.cache['B']+.8*rt.adj)[pairs[0],pairs[1]].clamp(1e-6,1-1e-6)
                delta=torch.logit(prob)-torch.logit(prior)
                mechanism={'CE':float(ce.detach()),'A':float(augmentation.detach()),
                    'saturation':float((delta.abs()>.95).float().mean()),
                    'residual_quantiles':torch.quantile(delta,delta.new_tensor([.05,.5,.95])).cpu().tolist(),
                    'original_probability':float(prob[target].mean()),'new_probability':float(prob[~target].mean())}
                if epoch==1:initial_mechanism=dict(mechanism)""")
change("row={'epoch':epoch,'training_loss'","row={'mechanism':mechanism,'epoch':epoch,'training_loss'")
change("result={'condition':condition","result={'initial_mechanism':initial_mechanism,'terminal_mechanism':mechanism,'condition':condition")
change("'classification_loss':'public probability-input cross entropy'","'classification_loss':'probability-input CE plus probability BCE coefficient1' if condition=='bce' else 'probability-input CE'")
source+='''\nif __name__=='__main__':
    MODE=sys.argv[1]
    results=[]
    for seed in (0,1,2):
        for condition in ('ce','bce'):
            results.append(run(seed,condition,False));torch.cuda.empty_cache()
    training.write_json(ROOT/(MODE+'-summary.json'),{'results':results})
'''
(ROOT/'src/train_bce.py').write_text(source)
(ROOT/'src/source-before-change.py').write_text(original)
shutil.copy2(Path(__file__),ROOT/'src/start_classification_bce.py')
eval_source=(OLD/'src/evaluate_joint_confirmation.py').read_text().replace("'frozen'","'ce'").replace("'joint'","'bce'").replace(' and improved_seeds>=2','')
(ROOT/'src/evaluate.py').write_text(eval_source)
def execute(stage,script,args,timeout):
    command=[sys.executable,'-u',str(ROOT/'src'/script),*args];start=time.monotonic()
    with (ROOT/(stage+'.log')).open('x') as f:
        try:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:code=124
    record={'exit_code':code,'elapsed_seconds':time.monotonic()-start,'command':command}
    (ROOT/(stage+'.exit.json')).write_text(json.dumps(record,indent=2));print(stage+' '+json.dumps(record),flush=True)
    if code:
        print((ROOT/(stage+'.log')).read_text()[-4500:]);sys.exit(code)
execute('short','train_bce.py',['short'],300)
results=json.loads((ROOT/'short-summary.json').read_text())['results']
pairs=[([r for r in results if r['seed']==s]) for s in (0,1,2)]
mean=lambda arm,key:sum(p[arm]['terminal_mechanism'][key] for p in pairs)/3
gate=mean(1,'saturation')<mean(0,'saturation') and mean(1,'A')<mean(0,'A') and all(b['terminal_mechanism']['saturation']<=a['terminal_mechanism']['saturation']+1e-8 for a,b in pairs)
(ROOT/'short-decision.json').write_text(json.dumps({'pass':gate,'CE_mean_saturation':mean(0,'saturation'),'BCE_mean_saturation':mean(1,'saturation'),'CE_mean_A':mean(0,'A'),'BCE_mean_A':mean(1,'A')},indent=2))
print('SHORT_GATE '+str(gate),flush=True)
if gate:
    execute('full','train_bce.py',['full'],900)
    # Persist the filename expected by the archived evaluator without replacing an existing file.
    for r in json.loads((ROOT/'full-summary.json').read_text())['results']:pass
    execute('evaluation','evaluate.py',[],180)
print('COMPLETE',flush=True)
