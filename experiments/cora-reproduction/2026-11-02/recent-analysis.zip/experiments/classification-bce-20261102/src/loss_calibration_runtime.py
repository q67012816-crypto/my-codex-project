"""Common exact loss definitions for the calibration-only comparison."""
import importlib.util
from pathlib import Path
import sys
import torch
import torch.nn.functional as F

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path(__file__).resolve().parent.parent
DELIVERY=WS/'outputs/reproduction-audit-20261102'
BASE=WS/'outputs/fairness-recheck-20261101/official-loss-models'
sys.path.insert(0,str(BASE/'src'))
import train_cora as training
spec=importlib.util.spec_from_file_location('calibration_gated_architecture',ROOT/'src/gated_models.py')
arch=importlib.util.module_from_spec(spec);spec.loader.exec_module(arch)
training.aligned_models=arch
torch.set_num_threads(4)
data,graph,adj,cache_cpu,g=training.load_inputs()
cache_cpu.update(torch.load(DELIVERY/'cache-for-inference.pt',map_location='cpu'))
cache={k:v.to(training.DEVICE) if isinstance(v,torch.Tensor) else v for k,v in cache_cpu.items() if k not in ('M','community_labels')}
active=data,graph,adj,cache,g
X=g.ndata['x'];N=data.num_nodes

def new_encoder():
    return training.model_new()

def forward_encoder(model,epoch=1):
    return model(g,adj,cache['sim'],cache['phi'],cache['B'],3,epoch,training.DEVICE,training.DEVICE)

def loss_terms(model,h,x_hat):
    cosine=F.normalize(h,dim=1)@F.normalize(h,dim=1).T
    S=sum((cosine-target).square().sum() for target in cache['logM'])/(len(cache['logM'])*N*N)
    F_loss=F.mse_loss(x_hat,X)
    A=2*F.binary_cross_entropy_with_logits(model.gcn.last_logits,model.gcn.last_targets,reduction='sum')/(N*N)
    return {'S':S,'F':F_loss,'A':A}

def parameter_groups(model):
    encoder=[(name,p) for name,p in model.named_parameters()
             if not name.startswith('gcn.') and not name.startswith('MLP_layer_x.')]
    augmentation=list(model.gcn.named_parameters())
    return encoder,augmentation

def flat_gradients(loss,named,retain=True):
    gradients=torch.autograd.grad(loss,[p for _,p in named],retain_graph=retain,allow_unused=True)
    assert all(torch.isfinite(v).all() for v in gradients if v is not None)
    return torch.cat([(torch.zeros_like(p) if grad is None else grad).detach().reshape(-1)
                      for (_,p),grad in zip(named,gradients)])

def vector_norm(vector):
    return float(vector.double().square().sum().sqrt())

def cosine(left,right):
    denominator=vector_norm(left)*vector_norm(right)
    return None if denominator==0 else float((left.double()*right.double()).sum()/denominator)

def diagnostics(model,terms,weights):
    enc,aug=parameter_groups(model)
    encS=flat_gradients(weights['S']*terms['S'],enc)
    encF=flat_gradients(weights['F']*terms['F'],enc)
    augS=flat_gradients(weights['S']*terms['S'],aug)
    augF=flat_gradients(weights['F']*terms['F'],aug)
    augA=flat_gradients(weights['A']*terms['A'],aug)
    return {'encoder_structure_gradient_norm':vector_norm(encS),
            'encoder_feature_gradient_norm':vector_norm(encF),
            'encoder_structure_to_feature':vector_norm(encS)/vector_norm(encF),
            'encoder_structure_feature_cosine':cosine(encS,encF),
            'augmentation_structure_gradient_norm':vector_norm(augS),
            'augmentation_feature_gradient_norm':vector_norm(augF),
            'augmentation_regularizer_gradient_norm':vector_norm(augA),
            'augmentation_reconstruction_gradient_norm':vector_norm(augS+augF),
            'augmentation_reconstruction_to_regularizer':vector_norm(augS+augF)/vector_norm(augA),
            'augmentation_structure_feature_cosine':cosine(augS,augF),
            'augmentation_reconstruction_regularizer_cosine':cosine(augS+augF,augA)}
