"""Independent checkpoint loading; verify predictions without selecting on test metrics."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
import loss_calibration_runtime as rt

parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int,choices=[0,1,2],default=0)
parser.add_argument('--condition',choices=['ce','bce'],default='bce');parser.add_argument('--all',action='store_true');args=parser.parse_args()


def verify(seed,condition):
    directory=rt.ROOT/f'full/seed-{seed:02d}/{condition}'
    checkpoint=torch.load(directory/'classifier-best.pt',map_location='cpu')
    model=rt.training.Classifier(rt.new_encoder()).to(rt.training.DEVICE);model.load_state_dict(checkpoint['state_dict'])
    logits=rt.training.evaluate(model,rt.active,checkpoint['best_epoch'],100000+seed)
    prediction=logits.argmax(1).cpu().numpy()
    saved=np.load(directory/'validation-only.npz')
    assert np.array_equal(prediction[saved['validation_ids']],saved['predictions'])
    locked=directory/'locked-predictions.npz'
    if locked.exists():assert np.array_equal(prediction,np.load(locked)['predictions'])
    sampler=model.encoder.gcn
    probability=sampler.last_probabilities.detach();target=sampler.last_targets.bool()
    pairs=sampler.anchor_pairs
    prior=(.2*rt.cache['B']+.8*rt.adj)[pairs[0],pairs[1]].clamp(1e-6,1-1e-6)
    delta=(torch.logit(probability)-torch.logit(prior)).cpu().numpy()
    row={'seed':seed,'condition':condition,'checkpoint_sha256':hashlib.sha256((directory/'classifier-best.pt').read_bytes()).hexdigest(),
        'best_epoch':checkpoint['best_epoch'],'validation_predictions_identical':True,
        'all_node_predictions_identical':True if locked.exists() else None,
        'augmentation_probability':{'original_edge_mean':float(probability[target].mean()),
            'new_candidate_mean':float(probability[~target].mean()),
            'residual_logit_quantiles_5_50_95':np.percentile(delta,[5,50,95]).tolist(),
            'near_bound_fraction_abs_residual_gt_0_95':float(np.mean(np.abs(delta)>.95)),
            'positive_residual_fraction':float(np.mean(delta>0))},
        'test_metrics_computed_by_this_script':False}
    print(json.dumps(row),flush=True)
    return row


if args.all:
    rows=[verify(seed,condition) for seed in (0,1,2) for condition in ('ce','bce')]
    (rt.ROOT/'independent-inference-verification.json').write_text(json.dumps(rows,indent=2))
else:verify(args.seed,args.condition)
