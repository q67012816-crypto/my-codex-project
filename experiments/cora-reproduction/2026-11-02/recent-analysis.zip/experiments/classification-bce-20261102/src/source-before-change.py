"""Single-change classification pilot: frozen versus trainable augmentation."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
import torch.nn.functional as F
import loss_calibration_runtime as rt

ROOT=rt.ROOT;training=rt.training
sys.path.insert(0,str(rt.DELIVERY/'src'))
from fairness_metrics import evaluate,generalized_degree


def measure(model,values,degree,epoch,seed):
    logits=training.evaluate(model,rt.active,epoch,100000+seed)
    prediction=logits.argmax(1).cpu().numpy();ids=values['val_ids'];truth=values['labels']
    metric=evaluate(prediction,truth,degree,ids,.2,'reference_percentile')
    assert not metric['missing_classes']
    recalls=np.array([[v['low_recall'],v['high_recall']] for v in metric['per_class']])
    selected={'accuracy':100*float(np.mean(prediction[ids]==truth[ids])),'SP':metric['SP'],'EO':metric['EO_strict'],
        'macro_worst_group_recall':100*float(recalls.min(1).mean()),'minimum_class_group_recall':100*float(recalls.min()),
        'per_class':metric['per_class'],'thresholds':metric['thresholds'],'low_n':metric['low_n'],'high_n':metric['high_n']}
    return selected,prediction[ids],logits.softmax(1).detach().cpu().numpy()[ids]


def run(seed,condition,smoke):
    stage='smoke' if smoke else 'full';dest=ROOT/stage/f'seed-{seed:02d}'/condition;dest.mkdir(parents=True,exist_ok=False)
    values=np.load(rt.DELIVERY/f'locked-predictions/p3-seed-{seed:02d}.npz')
    degree=generalized_degree(values['edge_index'],rt.N,1)
    labels=torch.as_tensor(values['labels'],device=training.DEVICE)
    train=torch.as_tensor(values['train_ids'],device=training.DEVICE)
    source=ROOT/'pretraining'/f'seed-{seed:02d}'/'baseline/pretrained.pt';source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
    training.seed_all(100+seed)
    model=training.Classifier(rt.new_encoder()).to(training.DEVICE)
    model.encoder.load_state_dict(torch.load(source,map_location='cpu')['state_dict'])
    trainable=condition=='joint'
    for parameter in model.encoder.gcn.parameters():parameter.requires_grad_(trainable)
    assert model.encoder.gcn.learn_augmentation
    sampler_initial={name:p.detach().clone() for name,p in model.encoder.gcn.named_parameters()}
    head_sha=hashlib.sha256(b''.join(p.detach().cpu().numpy().tobytes() for p in model.head.parameters())).hexdigest()
    config={'seed':seed,'condition':condition,'augmentation_trainable_during_classification':trainable,
        'max_epochs':2 if smoke else 500,'patience':100,'lr':1e-4,'weight_decay':1e-5,
        'classification_loss':'public probability-input cross entropy','selection':'strict validation accuracy, earlier ties',
        'source_pretrained_sha256':source_sha,'head_initial_sha256':head_sha,'test_metrics_computed':False,
        'architecture':'same archived bounded trainable augmentation; no PCGrad or new loss weights'}
    training.write_json(dest/'config.json',config)
    training.seed_all(810000+seed)
    optimizer=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=1e-4,weight_decay=1e-5)
    best=-1.;best_epoch=0;best_state=None;first_update=None;started=time.monotonic();step_times=[]
    with (dest/'history.jsonl').open('x') as stream:
        for epoch in range(1,config['max_epochs']+1):
            torch.cuda.synchronize();tick=time.perf_counter()
            model.train();optimizer.zero_grad(set_to_none=True)
            logits=model(rt.active,epoch)
            loss=F.cross_entropy(logits.softmax(1)[train],labels[train]);assert torch.isfinite(loss)
            loss.backward()
            if epoch==1:
                assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
                grads={name:float(p.grad.norm()) if p.grad is not None else None for name,p in model.encoder.gcn.named_parameters()}
                assert all(v is not None and v>0 for v in grads.values()) if trainable else all(v is None for v in grads.values())
            optimizer.step()
            if epoch==1:
                updates={name:float((p.detach()-sampler_initial[name]).abs().max()) for name,p in model.encoder.gcn.named_parameters()}
                assert all(v>0 for v in updates.values()) if trainable else all(v==0 for v in updates.values())
                first_update={'gradient_norms':grads,'parameter_max_abs_updates':updates}
            torch.cuda.synchronize()
            if 6<=epoch<=50:step_times.append(time.perf_counter()-tick)
            selected,_,_=measure(model,values,degree,epoch,seed)
            if selected['accuracy']>best:
                best=selected['accuracy'];best_epoch=epoch;best_state=training.cpu_state(model)
            row={'epoch':epoch,'training_loss':float(loss.detach()),'validation':selected,'best_epoch':best_epoch}
            stream.write(json.dumps(row)+'\n');stream.flush()
            if epoch<=2 or epoch%50==0:
                print('CLASSIFICATION '+json.dumps({'stage':stage,'condition':condition,'epoch':epoch,
                      'training_loss':float(loss.detach()),'validation_accuracy':selected['accuracy'],'EO':selected['EO'],'best_epoch':best_epoch}),flush=True)
            if epoch-best_epoch>=100:break
    last_sampler_delta={name:float((p.detach()-sampler_initial[name]).abs().max()) for name,p in model.encoder.gcn.named_parameters()}
    model.load_state_dict(best_state)
    selected,prediction,probabilities=measure(model,values,degree,best_epoch,seed)
    selected_sampler_delta={name:float((p.detach()-sampler_initial[name]).abs().max()) for name,p in model.encoder.gcn.named_parameters()}
    if trainable:assert all(v>0 for v in selected_sampler_delta.values())
    else:assert all(v==0 for v in last_sampler_delta.values())
    checkpoint={'state_dict':best_state,'config':config,'best_epoch':best_epoch,'evaluation_seed':100000+seed,
        'split':{k:torch.as_tensor(values[k+'_ids']) for k in ('train','val','test')}}
    torch.save(checkpoint,dest/'classifier-best.pt')
    restored=training.Classifier(rt.new_encoder()).to(training.DEVICE)
    restored.load_state_dict(torch.load(dest/'classifier-best.pt',map_location='cpu')['state_dict'])
    _,again,_=measure(restored,values,degree,best_epoch,seed);assert np.array_equal(prediction,again)
    np.savez_compressed(dest/'validation-only.npz',validation_ids=values['val_ids'],labels=values['labels'][values['val_ids']],
                        degree=degree[values['val_ids']],predictions=prediction,probabilities=probabilities)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
    result={'condition':condition,'seed':seed,'selected':selected,'best_epoch':best_epoch,'epochs_run':epoch,
        'first_update':first_update,'last_sampler_parameter_deltas':last_sampler_delta,
        'selected_sampler_parameter_deltas':selected_sampler_delta,'head_initial_sha256':head_sha,
        'source_checkpoint_unchanged':True,'reload_validation_predictions_identical':True,
        'median_train_step_seconds':float(np.median(step_times)) if step_times else None,
        'elapsed_seconds':time.monotonic()-started,'test_metrics_computed':False}
    training.write_json(dest/'result.json',result)
    print('ARM_COMPLETE '+json.dumps({k:v for k,v in result.items() if k not in ('first_update','last_sampler_parameter_deltas','selected_sampler_parameter_deltas')}),flush=True)
    return result


