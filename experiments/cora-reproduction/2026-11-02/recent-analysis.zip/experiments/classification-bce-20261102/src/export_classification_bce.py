import ast,csv,hashlib,json,shutil
from pathlib import Path
import numpy as np
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/classification-bce-20261102-01')
OUT=WS/'outputs/classification-bce-20261102'
assert not OUT.exists()
for p in ROOT.glob('*.exit.json'):assert json.loads(p.read_text())['exit_code']==0
short=json.loads((ROOT/'short-decision.json').read_text())
stage='full' if (ROOT/'full-summary.json').exists() else 'short'
results=json.loads((ROOT/(stage+'-summary.json')).read_text())['results']
for seed in (0,1,2):
    a,b=[r for r in results if r['seed']==seed]
    assert a['head_initial_sha256']==b['head_initial_sha256']
    assert abs(a['initial_mechanism']['CE']-b['initial_mechanism']['CE'])<1e-6
audit=[]
for r in results:
    v=np.load(ROOT/f"{stage}/seed-{r['seed']:02d}/{r['condition']}/validation-only.npz")
    y,p,d=v['labels'],v['predictions'],v['degree'];q=np.percentile(d,[20,80]);lo=d<=q[0];hi=d>q[1]
    gaps=[abs(np.mean(p[lo&(y==c)]==c)-np.mean(p[hi&(y==c)]==c)) for c in np.unique(y)]
    eo=100*float(np.mean(gaps));acc=100*float(np.mean(p==y))
    assert abs(eo-r['selected']['EO'])<1e-10 and abs(acc-r['selected']['accuracy'])<1e-10
    audit.append({'seed':r['seed'],'condition':r['condition'],'accuracy':acc,'EO':eo,'SP':r['selected']['SP']})
shutil.copytree(ROOT,OUT)
shutil.copy2(Path(__file__),OUT/'src/export_classification_bce.py')
verifier=(WS/'outputs/joint-augmentation-confirmation-20261102/src/predict_joint_confirmation.py').read_text().replace("'frozen'","'ce'").replace("'joint'","'bce'")
if stage=='short':verifier=verifier.replace("f'full/seed-", "f'short/seed-")
(OUT/'src/verify_predictions.py').write_text(verifier)
for p in (OUT/'src').glob('*.py'):ast.parse(p.read_text())
(OUT/'independent-validation-audit.json').write_text(json.dumps(audit,indent=2))
with (OUT/'comparison.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(audit[0]));writer.writeheader();writer.writerows(audit)
for n in ('environment.json','dependency-manifest.json'):shutil.copy2(WS/'outputs/joint-augmentation-confirmation-20261102'/n,OUT/n)
table='\n'.join(f"| {r['seed']} | {r['condition']} | {r['selected']['accuracy']:.2f} | {r['selected']['SP']:.2f} | {r['selected']['EO']:.2f} |" for r in results)
decision=json.loads((ROOT/'validation-decision.json').read_text()) if (ROOT/'validation-decision.json').exists() else None
test=json.loads((ROOT/'locked-test-results.json').read_text()) if (ROOT/'locked-test-results.json').exists() else None
summary={c:{k:float(np.mean([r['selected'][k] for r in results if r['condition']==c])) for k in ('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall')} for c in ('ce','bce')}
differences=[]
for seed in (0,1,2):
    a=np.load(ROOT/f'{stage}/seed-{seed:02d}/ce/validation-only.npz');b=np.load(ROOT/f'{stage}/seed-{seed:02d}/bce/validation-only.npz')
    differences.append({'seed':seed,'changed_validation_predictions':int(np.sum(a['predictions']!=b['predictions']))})
(OUT/'paired-prediction-differences.json').write_text(json.dumps(differences,indent=2))
text=f'''# 分类阶段增加增强BCE：实测结果

本轮唯一修改为联合分类目标CE→CE+A，A为完整N²归约的增强概率BCE，系数固定1。两条件均解冻增强器，复用相同3份预训练模型、新分类头初始化、采样流、划分、优化器与选轮次规则；没有重新预训练或改变模型。属于工程候选，不是作者已确认实现。

## 50轮机制检验

短流程通过：{short['pass']}。第50轮候选残差近上限比例的三种子均值：CE {short['CE_mean_saturation']*100:.3f}%，CE+A {short['BCE_mean_saturation']*100:.3f}%；原始A均值分别为{short['CE_mean_A']:.8f}、{short['BCE_mean_A']:.8f}。近上限定义为abs(logit(p)-logit(prior))>0.95。

预设短流程门槛为：更新有限，CE+A的平均饱和比例和A低于CE，且每个种子饱和比例不增加。增强网络8个参数张量均有有限非零梯度和实际更新。短流程结果不用于论文性能比较。

## 当前完成阶段：{stage}

| 种子 | 条件 | 验证准确率% | SP↓ | EO↓ |
|---|---|---:|---:|---:|
{table}

三种子验证均值：{json.dumps(summary,ensure_ascii=False)}。

配对验证预测变化数量：{json.dumps(differences,ensure_ascii=False)}。终轮残差饱和及CE/A详细数值在各result.json的terminal_mechanism，不能用短流程的饱和改善代替完整训练结论。

完整验证门槛：{decision['pass'] if decision else '未进入完整阶段'}。完整分类最多500轮、耐心100；只按验证准确率严格提高选模型，较早轮次优先，不按EO选模型。门槛在运行前固定为平均EO改善至少10%，每种子准确率下降不超过0.5个百分点，平均按类最差组召回和最小类组召回均不下降。未根据结果改门槛。

测试结果：{json.dumps(test['summary'],ensure_ascii=False) if test else '未计算本轮测试指标'}。当前不运行10次长训练。验证EO不能与论文测试EO4.26直接比较。

独立读取保存预测复算准确率和EO，与报告一致。全部分类检查点重载预测一致，源预训练检查点指纹不变，完整日志与退出状态保留。指标仍使用原简单图r1度数、划分内20/80百分位分组和逐类绝对召回差宏平均，没有混入训练节点评估。

目录保留源码、协议、预训练源权重、分类检查点、逐轮CE/A/残差分布、验证预测NPZ及比较CSV。依赖路径与环境沿用上次记录。历史模型、缓存和结果未覆盖。
'''
(OUT/'report.md').write_text(text,encoding='utf-8')
manifest=[{'path':str(p.relative_to(OUT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'stage':stage,'short':short,'validation_gate':decision['pass'] if decision else None,'summary':summary,'test':test['summary'] if test else None},indent=2),flush=True)
