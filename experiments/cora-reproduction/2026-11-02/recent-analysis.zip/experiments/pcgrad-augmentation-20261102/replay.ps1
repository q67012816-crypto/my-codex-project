$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/replay_pcgrad_augmentation.py').Replace('\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath
if ($LASTEXITCODE -ne 0) { throw "Replay failed, exit code $LASTEXITCODE" }
