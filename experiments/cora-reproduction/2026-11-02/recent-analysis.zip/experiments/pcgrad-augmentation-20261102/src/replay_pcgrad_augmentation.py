"""Replay a bounded PCGrad pilot without overwriting any existing run."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ARTIFACT=Path(__file__).resolve().parent.parent
for item in json.loads((ARTIFACT/'dependency-manifest.json').read_text()):
    path=Path(item['path'])
    assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],f'Dependency changed or missing: {path}'
ROOT=Path('/mnt/d/cgt-experiment')/('pcgrad-augmentation-replay-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
ROOT.mkdir(exist_ok=False)
shutil.copytree(ARTIFACT/'initial',ROOT/'initial');(ROOT/'src').mkdir()
for name in ('gated_models.py','loss_calibration_runtime.py','previous_training_io.py','pcgrad_two_task.py','run_pcgrad_augmentation.py'):
    shutil.copy2(ARTIFACT/'src'/name,ROOT/'src'/name)
shutil.copy2(ARTIFACT/'protocol.json',ROOT/'protocol.json')
print('NEW_EXPERIMENT_DIRECTORY '+str(ROOT),flush=True)


def execute(stage,arguments,timeout):
    command=[sys.executable,'-u',str(ROOT/'src/run_pcgrad_augmentation.py'),*arguments]
    tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
      'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-5000:]);sys.exit(code)


execute('short',['short'],300)
if not json.loads((ROOT/'short-summary.json').read_text())['pass']:
    print('STOPPED_SHORT_GATE_FAILED',flush=True);sys.exit(0)
execute('seed0',['full','--seeds','0'],600)
results=json.loads((ROOT/'full-0-summary.json').read_text())['results']
base,new=[v['selected'] for v in results]
expand=new['EO']<=.9*base['EO'] and new['accuracy']>=base['accuracy']-.5 and new['macro_worst_group_recall']>=base['macro_worst_group_recall']-1e-10 and new['minimum_class_group_recall']>=base['minimum_class_group_recall']-1e-10
(ROOT/'expansion-decision.json').write_text(json.dumps({'expand':expand,'base':base,'candidate':new,'test_metrics_computed':False},indent=2))
print('VALIDATION_EXPANSION_GATE '+str(expand),flush=True)
if expand:execute('remaining',['full','--seeds','1,2'],1200)
print('COMPLETE '+str(ROOT),flush=True)
