"""Two-task PCGrad sum, scoped explicitly to augmentation parameters."""
import torch


def project_pair(reconstruction,regularizer):
    left=reconstruction.double();right=regularizer.double()
    dot=torch.dot(left,right)
    norm_left=torch.dot(left,left);norm_right=torch.dot(right,right)
    active=bool(dot<0) and bool(norm_left>0) and bool(norm_right>0)
    if active:
        projected_left=left-(dot/norm_right)*right
        projected_right=right-(dot/norm_left)*left
    else:
        projected_left,projected_right=left,right
    merged=projected_left+projected_right
    denominator=(norm_left*norm_right).sqrt()
    info={'active':active,'raw_cosine':None if denominator==0 else float(dot/denominator),
          'reconstruction_norm':float(norm_left.sqrt()),'regularizer_norm':float(norm_right.sqrt()),
          'raw_sum_norm':float((left+right).norm()),'projected_sum_norm':float(merged.norm()),
          'projected_left_dot_original_right':float(torch.dot(projected_left,right)),
          'projected_right_dot_original_left':float(torch.dot(projected_right,left))}
    # A simultaneous descent direction for two non-opposite gradients in Euclidean coordinates.
    # This is a gradient property, not an Adam step guarantee.
    for original in (left,right):
        tolerance=1e-10*float(merged.norm()*original.norm())+1e-18
        assert float(torch.dot(merged,original))>=-tolerance
    return merged.to(reconstruction.dtype),info


def geometric_checks():
    checks=[]
    cases=[('aligned',[2.,0.],[1.,1.],[3.,1.],False),
           ('opposing_components',[1.,0.],[-1.,1.],[.5,1.5],True),
           ('exactly_opposite',[2.,0.],[-1.,0.],[0.,0.],True),
           ('one_zero',[0.,0.],[0.,2.],[0.,2.],False)]
    for name,left,right,expected,active in cases:
        actual,info=project_pair(torch.tensor(left),torch.tensor(right))
        assert torch.allclose(actual,torch.tensor(expected),atol=1e-7)
        assert info['active']==active
        checks.append({'case':name,'result':actual.tolist(),'active':active})
    return checks
