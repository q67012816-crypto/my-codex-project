"""Single-change, validation-only PCGrad experiment on the augmentation network."""
import argparse
import hashlib
import json
import sys
import time
import numpy as np
import torch
import loss_calibration_runtime as rt
from pcgrad_two_task import geometric_checks,project_pair
import previous_training_io as io

ROOT=rt.ROOT;training=rt.training
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
WEIGHTS=PROTOCOL['baseline_weights']


def replace_gradients(named,flat):
    offset=0
    for name,parameter in named:
        length=parameter.numel()
        parameter.grad=flat[offset:offset+length].reshape_as(parameter).clone()
        offset+=length
    assert offset==len(flat)


def pretrain(seed,condition,epochs,stage):
    dest=ROOT/stage/f'seed-{seed:02d}'/condition;dest.mkdir(parents=True,exist_ok=False)
    training.seed_all(seed)
    model=rt.new_encoder()
    model.load_state_dict(torch.load(ROOT/f'initial/seed-{seed:02d}.pt',map_location='cpu')['state_dict'])
    augmentation=list(model.gcn.named_parameters())
    remainder=[(name,p) for name,p in model.named_parameters() if not name.startswith('gcn.')]
    training.seed_all(900000+seed)
    optimizer=torch.optim.Adam(model.parameters(),lr=1e-4,weight_decay=1e-5)
    config={'seed':seed,'condition':condition,'weights':WEIGHTS,'epochs':epochs,
        'optimizer':'Adam lr1e-4 weight_decay1e-5','training_rng_seed':900000+seed,
        'selection':'minimum same weighted SSL objective, earlier ties; snapshot before optimizer update',
        'gradient_method':'ordinary total.backward' if condition=='baseline' else 'two-task PCGrad sum on augmentation parameters only',
        'tasks':{'R':'.5*S+.5*F','A':'1*A'},'raw_loss_definitions':PROTOCOL['raw_losses'],
        'classification':'identical archived classification procedure; validation accuracy only',
        'engineering_extension':True,'test_metrics_computed':False}
    io.write_json(dest/'pretrain-config.json',config)
    best=float('inf');best_epoch=0;best_state=None;step_times=[];diagnostics=[]
    conflict_epochs=[];unchanged_remainder_verified=False;split_gradients_checked=False
    first_update=None;started=time.monotonic()
    with (dest/'pretrain-history.jsonl').open('x') as history:
        for epoch in range(1,epochs+1):
            torch.cuda.synchronize();tick=time.perf_counter()
            model.train();optimizer.zero_grad(set_to_none=True)
            h,x_hat,sampled=rt.forward_encoder(model,epoch)
            terms=rt.loss_terms(model,h,x_hat)
            reconstruction=.5*terms['S']+.5*terms['F'];regularizer=terms['A'];total=reconstruction+regularizer
            assert torch.isfinite(total)
            row={'epoch':epoch,'weighted_total':float(total.detach()),
                 'raw_loss':{k:float(v.detach()) for k,v in terms.items()},**io.probability_stats(model,h)}
            diagnostic_epoch=epoch in (1,epochs) or epoch%50==0 or (epoch<=50 and epoch%5==0)
            if condition=='pcgrad' or diagnostic_epoch:
                grad_R=rt.flat_gradients(reconstruction,augmentation)
                grad_A=rt.flat_gradients(regularizer,augmentation)
                merged,projection=project_pair(grad_R,grad_A)
                row['augmentation_gradient']=projection
            if epoch in (1,epochs) or epoch%50==0:
                row['gradient_diagnostics']=rt.diagnostics(model,terms,WEIGHTS)
                diagnostics.append(row)
            if row['weighted_total']<best:
                best=row['weighted_total'];best_epoch=epoch;best_state=training.cpu_state(model)
            total.backward()
            if diagnostic_epoch and not split_gradients_checked:
                ordinary=torch.cat([p.grad.detach().reshape(-1) for _,p in augmentation])
                assert torch.allclose(ordinary,grad_R+grad_A,atol=2e-8,rtol=2e-4)
                split_gradients_checked=True
            if condition=='pcgrad' and projection['active']:
                conflict_epochs.append(epoch)
                verify=not unchanged_remainder_verified
                if verify:
                    before={name:p.grad.detach().clone() if p.grad is not None else None for name,p in remainder}
                replace_gradients(augmentation,merged)
                if verify:
                    assert all((p.grad is None and before[name] is None) or torch.equal(p.grad,before[name]) for name,p in remainder)
                    unchanged_remainder_verified=True
                    row['non_augmentation_gradients_unchanged']=True
                    del before
            if epoch in (1,epochs):
                assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
            if epoch==1:
                before={name:p.detach().clone() for name,p in augmentation}
                gradient_norms={name:float(p.grad.norm()) if p.grad is not None else None for name,p in augmentation}
                assert all(v is not None and v>0 for v in gradient_norms.values())
            optimizer.step()
            if epoch==1:
                updates={name:float((p.detach()-before[name]).abs().max()) for name,p in augmentation}
                assert all(v>0 for v in updates.values())
                first_update={'gradient_norms':gradient_norms,'parameter_max_abs_update':updates};del before
            torch.cuda.synchronize()
            if epoch>=6 and not diagnostic_epoch:step_times.append(time.perf_counter()-tick)
            row['best_epoch']=best_epoch
            history.write(json.dumps(row)+'\n');history.flush()
            if epoch<=2 or epoch%25==0 or epoch==epochs:
                print('PRETRAIN '+json.dumps({'seed':seed,'condition':condition,'stage':stage,**row}),flush=True)
    assert all(torch.isfinite(p).all() for p in model.parameters())
    if condition=='pcgrad':assert conflict_epochs and unchanged_remainder_verified
    torch.save({'state_dict':training.cpu_state(model),'config':config,'epoch':epochs},dest/'last-pretrained.pt')
    torch.save({'state_dict':best_state,'config':config,'best_epoch':best_epoch,'best_total_loss':best},dest/'pretrained.pt')
    model.load_state_dict(best_state);model.eval()
    with torch.no_grad(),torch.random.fork_rng(devices=[0]):
        training.seed_all(720000+seed);expected=rt.forward_encoder(model,best_epoch)[0].detach().clone()
    restored=rt.new_encoder();restored.load_state_dict(torch.load(dest/'pretrained.pt',map_location='cpu')['state_dict']);restored.eval()
    with torch.no_grad(),torch.random.fork_rng(devices=[0]):
        training.seed_all(720000+seed);actual=rt.forward_encoder(restored,best_epoch)[0]
    error=float((expected-actual).abs().max());assert error<1e-5
    result={'seed':seed,'condition':condition,'epochs':epochs,'weights':WEIGHTS,'best_epoch':best_epoch,
        'initial':diagnostics[0],'last':diagnostics[-1],'diagnostics':diagnostics,'first_update':first_update,
        'split_loss_gradients_match_total_gradient':split_gradients_checked,
        'non_augmentation_gradient_replacement_unchanged':unchanged_remainder_verified,
        'conflict_epochs':conflict_epochs,'conflict_fraction':len(conflict_epochs)/epochs if condition=='pcgrad' else None,
        'all_losses_and_parameters_finite':True,'checkpoint_reload_embedding_max_error':error,
        'median_training_step_seconds':float(np.median(step_times)),'elapsed_seconds':time.monotonic()-started,
        'test_metrics_computed':False}
    io.write_json(dest/'pretrain-result.json',result)
    print('PRETRAIN_COMPLETE '+json.dumps({k:v for k,v in result.items() if k not in ('initial','last','diagnostics','first_update','conflict_epochs')}),flush=True)
    return result


def short():
    io.write_json(ROOT/'geometry-checks.json',geometric_checks())
    results=[]
    for seed in (0,1,2):
        for condition in ('baseline','pcgrad'):
            results.append(pretrain(seed,condition,50,'short'));torch.cuda.empty_cache()
    for seed in (0,1,2):
        first=[v for v in results if v['seed']==seed]
        assert all(abs(first[0]['initial']['raw_loss'][k]-first[1]['initial']['raw_loss'][k])<1e-5 for k in ('S','F','A'))
    new=[v for v in results if v['condition']=='pcgrad']
    stable=all(all(v['last']['raw_loss'][k]<=2*v['initial']['raw_loss'][k] for k in ('S','F','A')) for v in new)
    noncollapsed=all(v['last']['node_feature_std']>=.1*v['initial']['node_feature_std'] for v in new)
    active=all(v['conflict_epochs'] and v['non_augmentation_gradient_replacement_unchanged'] for v in new)
    gate={'pass':stable and noncollapsed and active,'stable_losses':stable,'noncollapsed':noncollapsed,
          'projection_active_without_touching_other_gradients':active,'results':results,'test_metrics_computed':False}
    io.write_json(ROOT/'short-summary.json',gate)
    print('SHORT_GATE '+json.dumps({k:v for k,v in gate.items() if k!='results'}),flush=True)


def full(seeds):
    assert json.loads((ROOT/'short-summary.json').read_text())['pass']
    results=[]
    for seed in seeds:
        for condition in ('baseline','pcgrad'):
            pretrain(seed,condition,500,'full');torch.cuda.empty_cache()
            results.append(io.classify(seed,condition));torch.cuda.empty_cache()
        pair=[v for v in results if v['seed']==seed]
        assert pair[0]['head_initial_sha256']==pair[1]['head_initial_sha256']
    io.write_json(ROOT/('full-'+('-'.join(map(str,seeds)))+'-summary.json'),{'results':results,'test_metrics_computed':False})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['short','full']);parser.add_argument('--seeds',default='0');args=parser.parse_args()
    if args.stage=='short':short()
    else:full(list(map(int,args.seeds.split(','))))
