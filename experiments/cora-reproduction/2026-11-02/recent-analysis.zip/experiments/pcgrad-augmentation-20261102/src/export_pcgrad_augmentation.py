import ast
import csv
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/pcgrad-augmentation-20261102-01')
OUT=WS/'outputs/pcgrad-augmentation-20261102'
assert not OUT.exists()
short=json.loads((ROOT/'short-summary.json').read_text())
decision=json.loads((ROOT/'expansion-decision.json').read_text())
results=[]
for path in sorted(ROOT.glob('full-*-summary.json')):results+=json.loads(path.read_text())['results']
for path in ROOT.glob('*.exit.json'):assert json.loads(path.read_text())['exit_code']==0
audits=[]
for item in results:
    path=ROOT/'full'/f"seed-{item['seed']:02d}"/item['condition']
    v=np.load(path/'validation-only.npz');truth=v['labels'];prediction=v['predictions'];degree=v['degree']
    q=np.percentile(degree,[20,80]);low=degree<=q[0];high=degree>q[1]
    sp=[];eo=[];recalls=[]
    for c in np.unique(truth):
        a=low&(truth==c);b=high&(truth==c);assert a.any() and b.any()
        lo=float(np.mean(prediction[a]==c));hi=float(np.mean(prediction[b]==c))
        eo.append(abs(lo-hi));sp.append(abs(np.mean(prediction[low]==c)-np.mean(prediction[high]==c)))
        recalls.append([lo,hi])
    audit={'seed':item['seed'],'condition':item['condition'],'accuracy':100*float(np.mean(prediction==truth)),
           'SP':100*float(np.mean(sp)),'EO':100*float(np.mean(eo)),
           'macro_worst_group_recall':100*float(np.min(recalls,axis=1).mean()),
           'minimum_class_group_recall':100*float(np.min(recalls)),
           'validation_n':len(truth),'low_n':int(low.sum()),'high_n':int(high.sum()),'thresholds':q.tolist()}
    for key in ('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall'):
        assert abs(audit[key]-item['selected'][key])<1e-10
    audits.append(audit)
shutil.copytree(ROOT,OUT)
shutil.copy2(WS/'work/replay_pcgrad_augmentation.py',OUT/'src/replay_pcgrad_augmentation.py')
shutil.copy2(Path(__file__),OUT/'src/export_pcgrad_augmentation.py')
for name in ('environment.json','dependency-manifest.json'):
    shutil.copy2(WS/'outputs/loss-calibration-20261102'/name,OUT/name)
for path in (OUT/'src').glob('*.py'):ast.parse(path.read_text())
(OUT/'independent-validation-audit.json').write_text(json.dumps(audits,indent=2))
keys=['seed','condition','accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall','validation_n','low_n','high_n']
with (OUT/'validation-comparison.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader()
    writer.writerows([{k:v[k] for k in keys} for v in audits])
for item in results:
    v=np.load(OUT/'full'/f"seed-{item['seed']:02d}"/item['condition']/'validation-only.npz')
    with (OUT/f"validation-predictions-seed-{item['seed']:02d}-{item['condition']}.csv").open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['node_id','label','prediction','original_degree'])
        writer.writerows(zip(v['validation_ids'],v['labels'],v['predictions'],v['degree']))
table='\n'.join(f"| {v['seed']} | {v['condition']} | {v['accuracy']:.2f} | {v['SP']:.2f} | {v['EO']:.2f} | {v['macro_worst_group_recall']:.2f} | {v['minimum_class_group_recall']:.2f} |" for v in audits)
short_rows=[]
for item in short['results']:
    if item['condition']=='pcgrad':
        baseline=next(v for v in short['results'] if v['seed']==item['seed'] and v['condition']=='baseline')
        short_rows.append(f"| {item['seed']} | {item['conflict_epochs'][0]} | {len(item['conflict_epochs'])}/50 | {item['last']['raw_loss']['S']:.6f} | {item['last']['raw_loss']['F']:.6f} | {baseline['median_training_step_seconds']*1000:.1f} | {item['median_training_step_seconds']*1000:.1f} |")
shorttable='\n'.join(short_rows)
base,new=audits[:2]
conclusion='种子0通过预设门槛，已扩展种子1/2；跨种子结论须结合下表全部结果。' if decision['expand'] else '种子0未通过预设公平性收益门槛，未扩展种子1/2，也未将PCGrad设为默认。'
report=f'''# 增强模块双任务PCGrad：下一步的实测检验

本轮针对训练中的方向冲突，只改变增强网络的梯度合并方式，损失权重恢复0.5S+0.5F+A。{conclusion}

这是我们的工程扩展，不是DegFairGT作者公开的训练方法，不能据此声称已复现论文EO=4.26。所有新增公平性结果均为验证集，未计算本轮测试指标。

## 选择这一步的依据

上轮原权重在三个种子第50轮的增强重构/正则梯度余弦为−0.993、−0.967、−0.993；种子0第500轮约−0.986。静态标定只能改变大小，不能改变方向。现在用一个可检验的实验判断处理这一冲突是否改善EO。

## 改动范围与算法

设gR=∇aug(0.5S+0.5F)，gA=∇aug(A)。当gR·gA<0时，分别计算gR'=gR−(gR·gA/‖gA‖²)gA和gA'=gA−(gA·gR/‖gR‖²)gR，再使用gR'+gA'。两次投影都基于原始梯度。无冲突时完全保留普通total.backward得到的梯度。

只替换增强模块的8个参数张量；编码器和特征解码器仍使用原始总损失梯度。两任务的投影不需要随机排列。严格相反时投影梯度为0，近乎相反可能明显缩小更新，因此记录投影前后范数与实际参数变化，而不是把余弦变小当成性能成功。

依据[PCGrad原论文算法1](https://proceedings.neurips.cc/paper/2020/hash/3fe78a8acf5fda99de95303940a2420c-Abstract.html)及[作者实现仓库](https://github.com/tianheyu927/PCGrad)。本轮限定在增强子模块的两项目标上；不是对全模型3项损失应用PCGrad，也没有同时加入动态权重、公平性惩罚或改变网络。

## 短流程和完整训练

| 种子 | 首次冲突轮次 | 50轮内投影次数 | S50 | F50 | 原训练步中位ms | PCGrad训练步中位ms |
|---|---:|---:|---:|---:|---:|---:|
{shorttable}

3种子×2条件×50轮均有限，表示未塌缩，增强参数有实际更新。校验了分项梯度和与普通总损失梯度的一致性；替换时其他模块梯度逐元素保持不变。几何检查覆盖同向、冲突、严格反向和零梯度。所有预训练检查点固定采样恢复后的嵌入最大误差为0；所有分类检查点恢复后验证预测一致。

两条件使用相同架构指纹、初始化检查点、数据/结构缓存、采样与dropout随机种子、Adam lr1e-4/weight_decay1e-5。完整预训练各500轮，按相同加权训练SSL目标最小值选权重，保存产生该目标的更新前状态。分类最多500轮、耐心100，按验证准确率严格改善选轮次；保留此前公共实现的概率输入交叉熵；两条件冻结各自的增强网络并保留学到的概率，分类头初始指纹相同。

短流程及完整训练的诊断会额外计算分项梯度。PCGrad每轮比普通训练多计算增强参数的重构与正则梯度；上表为顺序运行计时，不能作为严格的硬件速度基准。

## 验证结果

| 种子 | 条件 | 准确率%↑ | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---|---:|---:|---:|---:|---:|
{table}

种子0标定后减原权重：准确率{new['accuracy']-base['accuracy']:+.2f}个百分点，SP{new['SP']-base['SP']:+.2f}个百分点，EO{new['EO']-base['EO']:+.2f}个百分点。这里“标定后”指本轮梯度投影，不是上轮固定系数。

预设扩展门槛为：种子0验证EO相对下降至少10%，准确率下降不超过0.5个百分点，按类最差组召回均值与全部类组最小召回都不下降。门槛在结果前写入protocol.json；未按测试集或看到结果后调门槛。

种子0验证节点541个。r=1，按原始简单图度数，在验证集内取20/80百分位，低组≤2、高组>5，分别204/80个节点。EO为7类条件召回差的绝对值宏平均×100；无缺失类别。已从保存的验证预测独立复算与原报告一致。不能与论文测试指标直接横比，也不能把梯度冲突当作EO偏差的已证实原因。

## 保存与复跑

本目录保存协议、源码、初始权重、全部日志/退出码、预训练与分类检查点、验证NPZ和逐节点CSV。dependency-manifest.json记录复用数据、缓存和源码的指纹；environment.json沿用本机相同环境记录。历史实验未覆盖。

执行replay.ps1会检查依赖并在D:/cgt-experiment新建带时间戳的目录，依次进行短流程、种子0完整训练以及按预设验证门槛决定是否扩展种子1/2。复用Ubuntu-D/cgt环境和已有数据，不重装、不下载、不覆盖历史结果。CUDA独立重训可能存在细小数值差异；同一检查点的恢复验证已经通过。
'''
report=report.replace('种子0标定后减原权重','种子0PCGrad减原权重').replace('这里“标定后”指本轮梯度投影，不是上轮固定系数。','本轮两条件损失系数相同。')
(OUT/'report.md').write_text(report,encoding='utf-8')
ps1='''$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/replay_pcgrad_augmentation.py').Replace('\\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath
if ($LASTEXITCODE -ne 0) { throw "Replay failed, exit code $LASTEXITCODE" }
'''
(OUT/'replay.ps1').write_text(ps1)
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'files':len(manifest)+1,'expand':decision['expand'],'validation_audit':audits},indent=2),flush=True)
