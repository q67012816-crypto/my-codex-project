import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
PREVIOUS=WS/'outputs/loss-calibration-20261102'
ROOT=Path('/mnt/d/cgt-experiment/pcgrad-augmentation-20261102-01')
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir();(ROOT/'initial').mkdir()
for name in ('gated_models.py','loss_calibration_runtime.py'):
    shutil.copy2(PREVIOUS/'src'/name,ROOT/'src'/name)
shutil.copy2(PREVIOUS/'src/run_loss_calibration.py',ROOT/'src/previous_training_io.py')
for name in ('pcgrad_two_task.py','run_pcgrad_augmentation.py','launch_pcgrad_augmentation.py'):
    shutil.copy2(WS/'work'/name,ROOT/'src'/name)
for seed in (0,1,2):
    shutil.copy2(PREVIOUS/f'calibration/initial-seed-{seed:02d}.pt',ROOT/f'initial/seed-{seed:02d}.pt')
previous=json.loads((PREVIOUS/'protocol.json').read_text())
protocol={'date':'2026-11-02 Asia/Seoul','baseline_weights':{'S':.5,'F':.5,'A':1},
    'raw_losses':previous['raw_losses'],'architecture_sha256':previous['architecture_sha256'],
    'only_changed_factor':'two-task PCGrad gradient sum ONLY on the8 augmentation parameter tensors',
    'scope':'engineering modification on previously reconstructed augmentation; not a claimed original-paper implementation',
    'reference':'https://proceedings.neurips.cc/paper/2020/hash/3fe78a8acf5fda99de95303940a2420c-Abstract.html',
    'authors_code':'https://github.com/tianheyu927/PCGrad',
    'tasks':{'R':'.5*mean structure+.5*MSE feature','A':'full N*N mean probability BCE'},
    'projection':'If gR dot gA<0, project BOTH original gradients onto the normal plane of the other original gradient; merge by SUM. If no conflict, keep original total.backward gradients exactly.',
    'parameter_scope':'augmentation GCN/MLP only; encoder and decoder gradients are never replaced',
    'optimizer':'Adam lr1e-4 weight_decay1e-5; same initial state and RNG streams for each pair',
    'geometric_limit':'exactly opposite gradients yield zero projected task gradient; near-opposition may suppress learning; inspect norm and actual updates',
    'short':{'seeds':[0,1,2],'epochs':50},
    'short_gate':'finite, noncollapsed; each raw S/F/A terminal<=2*initial; actual conflict projections active and non-augmentation gradients unmodified',
    'full':{'first_seed':0,'pretrain_epochs':500,'classification_epochs':500,'patience':100,
      'classification':'exact archived classification routine, train CE on probabilities; freeze learned augmentation in BOTH arms',
      'pretrain_selection':'minimum SAME weighted training SSL objective, before-update snapshot, earlier ties',
      'classification_selection':'strict validation accuracy, earlier ties; no EO selection'},
    'remaining_seed_gate':'seed0 validation EO improves>=10%; accuracy drop<=0.5pp; macro worst-group and minimum class-group recall do not decrease',
    'max_remaining_seeds':[1,2],'no_test_based_tuning':True,'test_metrics_computed':False}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
assert hashlib.sha256((ROOT/'src/gated_models.py').read_bytes()).hexdigest()==protocol['architecture_sha256']


def execute(stage,arguments,timeout):
    command=[sys.executable,'-u',str(ROOT/'src/run_pcgrad_augmentation.py'),*arguments]
    tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
      'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-5000:]);sys.exit(code)


execute('short',['short'],300)
if not json.loads((ROOT/'short-summary.json').read_text())['pass']:
    print('STOPPED_SHORT_GATE_FAILED',flush=True);sys.exit(0)
execute('seed0',['full','--seeds','0'],600)
result=json.loads((ROOT/'full-0-summary.json').read_text())['results']
base,improved=[r['selected'] for r in result]
expand=improved['EO']<=.9*base['EO'] and improved['accuracy']>=base['accuracy']-.5 and improved['macro_worst_group_recall']>=base['macro_worst_group_recall']-1e-10 and improved['minimum_class_group_recall']>=base['minimum_class_group_recall']-1e-10
(ROOT/'expansion-decision.json').write_text(json.dumps({'expand':expand,'base':base,'candidate':improved,'test_metrics_computed':False},indent=2))
print('VALIDATION_EXPANSION_GATE '+str(expand),flush=True)
if expand:execute('remaining',['full','--seeds','1,2'],1200)
print('COMPLETE',flush=True)
