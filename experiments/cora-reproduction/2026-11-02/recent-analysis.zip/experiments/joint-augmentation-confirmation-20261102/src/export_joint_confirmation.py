import ast
import csv
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/joint-augmentation-confirmation-20261102-01')
OUT=WS/'outputs/joint-augmentation-confirmation-20261102'
assert not OUT.exists()
decision=json.loads((ROOT/'validation-decision.json').read_text())
for path in ROOT.glob('*.exit.json'):assert json.loads(path.read_text())['exit_code']==0
audits=[]


def audit(truth,prediction,degree):
    q=np.percentile(degree,[20,80]);low=degree<=q[0];high=degree>q[1];sp=[];eo=[];recalls=[]
    for c in np.unique(truth):
        a=low&(truth==c);b=high&(truth==c);assert a.any() and b.any()
        lo=float(np.mean(prediction[a]==c));hi=float(np.mean(prediction[b]==c));recalls.append([lo,hi]);eo.append(abs(lo-hi))
        sp.append(abs(np.mean(prediction[low]==c)-np.mean(prediction[high]==c)))
    return {'accuracy':100*float(np.mean(prediction==truth)),'SP':100*float(np.mean(sp)),'EO':100*float(np.mean(eo)),
            'macro_worst_group_recall':100*float(np.min(recalls,axis=1).mean()),'minimum_class_group_recall':100*float(np.min(recalls))}


for record in decision['results']:
    path=ROOT/f"full/seed-{record['seed']:02d}/{record['condition']}"
    values=np.load(path/'validation-only.npz')
    row=audit(values['labels'],values['predictions'],values['degree'])
    assert all(abs(row[key]-record['selected'][key])<1e-10 for key in row)
    audits.append({'seed':record['seed'],'condition':record['condition'],'split':'validation',**row})
test_path=ROOT/'locked-test-results.json'
test=json.loads(test_path.read_text()) if test_path.exists() else None
if test:
    assert decision['pass']
    for record in test['results']:
        values=np.load(ROOT/f"full/seed-{record['seed']:02d}/{record['condition']}/locked-predictions.npz")
        ids=values['test_ids'];row=audit(values['labels'][ids],values['predictions'][ids],values['degree'][ids])
        assert all(abs(row[key]-record[key])<1e-10 for key in ('accuracy','SP','EO'))
        audits.append({'seed':record['seed'],'condition':record['condition'],'split':'test',**row})
shutil.copytree(ROOT,OUT)
for name in ('predict_joint_confirmation.py','export_joint_confirmation.py'):
    shutil.copy2(WS/'work'/name,OUT/'src'/name)
for name in ('dependency-manifest.json','environment.json'):
    shutil.copy2(WS/'outputs/loss-calibration-20261102'/name,OUT/name)
for path in (OUT/'src').glob('*.py'):ast.parse(path.read_text())
(OUT/'independent-audit.json').write_text(json.dumps(audits,indent=2))
with (OUT/'comparison.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(audits[0]));writer.writeheader();writer.writerows(audits)
for seed in (0,1,2):
    for condition in ('frozen','joint'):
        directory=OUT/f'full/seed-{seed:02d}/{condition}'
        npz=directory/('locked-predictions.npz' if test else 'validation-only.npz');v=np.load(npz)
        ids=np.arange(len(v['labels'])) if test else v['validation_ids']
        with (directory/'node-predictions.csv').open('w',newline='') as stream:
            writer=csv.writer(stream);writer.writerow(['node_id','label','prediction','original_degree'])
            writer.writerows(zip(ids,v['labels'],v['predictions'],v['degree']))
table='\n'.join(f"| {v['seed']} | {v['condition']} | {v['selected']['accuracy']:.2f} | {v['selected']['SP']:.2f} | {v['selected']['EO']:.2f} | {v['selected']['macro_worst_group_recall']:.2f} | {v['selected']['minimum_class_group_recall']:.2f} |" for v in decision['results'])
means='\n'.join(f"| {condition} | {v['accuracy']:.2f} | {v['SP']:.2f} | {v['EO']:.2f} | {v['macro_worst_group_recall']:.2f} | {v['minimum_class_group_recall']:.2f} |" for condition,v in decision['summary'].items())
conclusion='跨种子验证通过预设门槛，随后锁定joint为本轮主方案并统一测试；没有按测试结果重新选择。' if decision['pass'] else '种子0的改善没有通过预设跨种子门槛。未执行本轮测试，也未将联合增强设为已确认的新默认。'
test_text='本轮未计算测试指标。'
if test:
    test_rows='\n'.join('| '+condition+' | '+' | '.join(f"{v[key]['mean']:.2f}±{v[key]['std_ddof0']:.2f}" for key in ('accuracy','SP','EO'))+' |' for condition,v in test['summary'].items())
    test_text=f'''| 测试方案 | 准确率% | SP↓ | EO↓ |
|---|---:|---:|---:|
| 论文（10次） | 87.10±1.53 | 3.46±0.97 | 4.26±0.24 |
{test_rows}

本轮各3种子，±为总体标准差ddof0。3次不能替代论文10次；这些Cora测试划分已在此前研究中见过，并非全新未接触测试集。固定配置后统一评分，未按测试结果改选模型或种子。'''
report=f'''# 联合训练增强器：三种子确认

{conclusion}

本轮接续的具体修改是分类阶段允许增强GCN/MLP参与监督优化。原公开代码把预训练模型全部参数设为可训练，近期隔离预训练实验为了控制因素冻结了增强器。当前架构的概率生成路径仍是我们的可审计重建，不能声称公开代码已经完整实现该可学习增强，也不能把这项解冻等同于已恢复作者全部训练细节。

此前静态标定验证失败；增强模块PCGrad虽使种子0EO9.92→8.33，但准确率83.55%→82.44%，未通过精度门槛，未叠加进本轮。

## 配对设计与已完成训练

种子0的冻结/联合分类结果和原权重预训练状态直接保留。种子1/2分别从各自原初始化预训练500轮，损失始终0.5S+0.5F+A；每个种子的两条件共用同一预训练检查点、相同新分类头初始化100+seed、训练采样810000+seed和评估采样100000+seed。其余模型、候选边、缓存、数据划分、损失输入和系数、Adam学习率1e-4/weight_decay1e-5都固定。

分类最多500轮、耐心100，公共行为的概率输入CE，严格按验证准确率提高选权重，较早轮次优先；未按EO选模型。预训练按相同训练SSL目标最低值保存更新前状态。新预训练日志、所有分类历史和检查点都已保留。

参数化种子的代码差异保存在evidence/seed-generalization.diff，没有改变训练规则。每个联合条件增强网络8个参数张量均有有限非零监督梯度和实际更新；冻结条件参数不变。原预训练文件指纹不变，全部分类检查点重载后验证预测一致。

## 验证结果

| 种子 | 条件 | 准确率% | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---|---:|---:|---:|---:|---:|
{table}

| 3种子验证均值 | 准确率% | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---:|---:|---:|---:|---:|
{means}

确认阶段开始前登记门槛：平均EO改善至少10%，至少2/3种子EO改善，每个种子准确率下降不超过0.5个百分点，平均按类最差组召回和平均全部类组最小召回均不下降。门槛结果见validation-decision.json，未根据后续分数调整。

## 测试

{test_text}

## 指标和独立复核

公平性始终使用原始简单图r=1度数，在对应验证或测试划分内取20/80百分位，低组≤q20、高组>q80，包含同度并列。EO为7类条件召回差的绝对值宏平均×100，没有用有符号平均抵消。所有新增验证结果，以及存在时的测试结果，都已从保存预测用独立计数实现复算一致，详见independent-audit.json和comparison.csv。

单个种子验证EO不能与论文测试EO直接比较。研究中的多次验证诊断属于探索，不是独立未接触验证。即使此次指标改善，也需要区分工程改进与原始作者实现的精确复现。

## 交付与下一步

full/seed-XX/frozen与joint包含分类模型、配置、逐轮日志、验证预测和CSV；pretraining包含各种子的预训练模型和日志。所有文件在D盘保留，未覆盖此前正式模型。predict.ps1可以独立加载所选检查点并复核保存预测。推理仍复用Ubuntu-D/cgt与既有Cora缓存；它是Cora节点分类模型，不是可直接部署的企业关系识别器。

若确认未通过，继续定位可学习增强概率参数化、损失语义和作者EO评估协议的差异，不把单个好种子扩成“复现成功”。若确认通过，固定此版本后再决定论文要求的10次统计，不在这一步启动10次长训练。本轮无论结果如何都不通过调指标分组、混入训练节点或挑选种子追求4.26。
'''
verification=json.loads((ROOT/'independent-inference-verification.json').read_text())
near=[v['augmentation_probability']['near_bound_fraction_abs_residual_gt_0_95'] for v in verification if v['condition']=='joint']
report+=f'''

## 新定位：联合训练时残差几乎全部饱和

独立重新加载6个分类检查点并固定采样，全部验证预测与原保存结果一致。额外读取增强概率相对于原始先验的logit残差：3个联合模型中，|残差|>0.95的候选对分别占{', '.join(f'{100*v:.3f}%' for v in near)}，正残差占比均为100%。残差由tanh限制在[-1,1]，5/50/95百分位也已保存于independent-inference-verification.json。

这说明当前GCN残差几乎都推向同一个正上限，可学习部分接近统一提高采样概率。原有度数先验仍会区分边，不能据此说全部边概率相同，也不能断言这个现象已经解释EO差距。

下一项只比较联合分类时CE与CE+A：A沿用全N²平均、概率输入的原图BCE和系数1，保留现有预训练检查点及其他全部设置。检验分类阶段恢复增强正则是否抑制残差饱和；这是待验证的工程修正，尚未训练或证明有效。先做50轮配对，确认梯度、更新和残差分布，再决定完整分类与跨种子验证；不启动10次训练。具体协议见next-step.md。
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
next_step='''# 下一项独立检验：联合分类阶段的增强正则

当前观察：种子0联合分类EO大幅下降，三种子验证平均只改善约9.40%；种子1准确率下降约0.74个百分点。三种子未通过预设门槛，未测试，也没有选择一个好种子替换正式基线。

新增的可核查问题：联合分类的3个模型有98.938%–99.959%的候选边，其可学习logit残差满足abs(delta)>0.95（tanh理论上限1），全部delta>0。可学习残差趋于同向饱和。当前分类只优化CE，没有保留预训练阶段的增强BCE。两件事相关，尚不能证明因果。

唯一改动：联合分类目标由CE改为CE+A。A=2*sum_upper BCEWithLogits(augmentation_logits,original_adjacency)/(N*N)，系数固定1，不搜索。CE继续采用公开概率输入行为。这个分类目标是我们的工程候选，论文没有明确确认它。

固定项：复用本目录3份原权重预训练模型；相同分类头初始化、采样流、节点划分、评估、优化器、学习率、耐心和轮数。两条件均解冻增强器。不叠加PCGrad，不采用上轮静态标定权重，不添加结构/特征损失或其他公平性项。

先做每种子两个条件各50轮：记录A原始值、CE原始值、增强器梯度和参数变化、残差分位数、近上限比例、原边/新候选概率。短流程只判断数值/机制，不用低准确率时的较低EO宣称成功。

机制检查通过后再做完整分类。沿用验证准确率选轮次；三种子平均EO相对下降至少10%、每种子精度下降不超过0.5个百分点、平均最差组及最小类组召回不下降，才允许锁定后读测试。任何失败均保留，不改门槛或挑种子。仅通过这些检查也不能自动称为作者原版复现。

这一候选尚未执行。本轮已完成的是PCGrad、冻结/联合分类对照及联合分类三种子确认；没有在报告中预填未来成绩。
'''
(OUT/'next-step.md').write_text(next_step,encoding='utf-8')
ps1='''param([ValidateSet(0,1,2)][int]$Seed = 0, [ValidateSet('frozen','joint')][string]$Condition = 'joint')
$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/predict_joint_confirmation.py').Replace('\\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath --seed $Seed --condition $Condition
if ($LASTEXITCODE -ne 0) { throw "Prediction verification failed, exit code $LASTEXITCODE" }
'''
(OUT/'predict.ps1').write_text(ps1)
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'files':len(manifest)+1,'validation_gate':decision['pass'],'validation_summary':decision['summary'],'test_summary':test['summary'] if test else None},indent=2),flush=True)
