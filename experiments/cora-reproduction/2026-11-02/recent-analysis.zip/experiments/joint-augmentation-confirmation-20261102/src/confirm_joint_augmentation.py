"""Freeze the successful pilot settings before adding seeds1/2 and possible test evaluation."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
PILOT=Path('/mnt/d/cgt-experiment/joint-augmentation-classification-20261102-01')
CAL=WS/'outputs/loss-calibration-20261102'
ROOT=Path('/mnt/d/cgt-experiment/joint-augmentation-confirmation-20261102-01')
assert json.loads((PILOT/'adoption-decision.json').read_text())['adopt']
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir();(ROOT/'calibration').mkdir();(ROOT/'evidence').mkdir()
protocol=json.loads((PILOT/'protocol.json').read_text())
protocol.update({'confirmation_seeds':[0,1,2],'seed0':'completed pilot copied without retraining or replacement',
    'baseline_weights':{'S':.5,'F':.5,'A':1},'raw_losses':json.loads((CAL/'protocol.json').read_text())['raw_losses'],
    'pretraining_seeds1_2':'500epochs same original-weight SSL; shared by frozen/joint classifiers within each seed',
    'validation_gate':'mean EO improves>=10%, mean worst-group recall and mean minimum class-group recall nondecreasing; at least2of3 seeds EO improves; accuracy drop<=0.5pp in EACH seed',
    'test_plan':'Only if validation gate passes: lock joint as primary, evaluate all3 checkpoints and frozen comparators once on test; no tuning or replacing seeds after test',
    'test_history':'these Cora test splits were seen in earlier research; not an untouched independent confirmation set'})
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
shutil.copy2(CAL/'calibration.json',ROOT/'calibration.json')
for seed in (0,1,2):shutil.copy2(CAL/f'calibration/initial-seed-{seed:02d}.pt',ROOT/f'calibration/initial-seed-{seed:02d}.pt')
for name in ('gated_models.py','loss_calibration_runtime.py'):
    shutil.copy2(PILOT/'src'/name,ROOT/'src'/name)
shutil.copy2(CAL/'src/run_loss_calibration.py',ROOT/'src/previous_training_io.py')
shutil.copytree(PILOT/'full',ROOT/'full/seed-00')
shutil.copytree(CAL/'full/seed-00/baseline',ROOT/'pretraining/seed-00/baseline')
source=(PILOT/'src/run_joint_augmentation.py').read_text()
(ROOT/'evidence/seed0-classification-source.py').write_text(source)
generalized=source
replacements=[
 ('def measure(model,values,degree,epoch):','def measure(model,values,degree,epoch,seed):'),
 ('epoch,100000)','epoch,100000+seed)'),
 ('def run(condition,smoke):','def run(seed,condition,smoke):'),
 ("dest=ROOT/stage/condition","dest=ROOT/stage/f'seed-{seed:02d}'/condition"),
 ("values=np.load(rt.DELIVERY/'locked-predictions/p3-seed-00.npz')","values=np.load(rt.DELIVERY/f'locked-predictions/p3-seed-{seed:02d}.npz')"),
 ("source=ROOT/'source-pretrained.pt'","source=ROOT/'pretraining'/f'seed-{seed:02d}'/'baseline/pretrained.pt'"),
 ('training.seed_all(100)','training.seed_all(100+seed)'),
 ("'seed':0","'seed':seed"),
 ('training.seed_all(810000)','training.seed_all(810000+seed)'),
 ('measure(model,values,degree,epoch)','measure(model,values,degree,epoch,seed)'),
 ('measure(model,values,degree,best_epoch)','measure(model,values,degree,best_epoch,seed)'),
 ('measure(restored,values,degree,best_epoch)','measure(restored,values,degree,best_epoch,seed)'),
 ("'evaluation_seed':100000","'evaluation_seed':100000+seed")]
for old,new in replacements:
    assert old in generalized,old
    generalized=generalized.replace(old,new)
generalized=generalized.split("if __name__=='__main__':")[0]+'''if __name__=='__main__':
    import previous_training_io as pretraining
    for seed in (1,2):
        pretraining.pretrain(seed,'baseline',500,'pretraining')
        torch.cuda.empty_cache()
        for condition in ('frozen','joint'):
            run(seed,condition,False)
            torch.cuda.empty_cache()
'''
(ROOT/'src/run_joint_confirmation.py').write_text(generalized)
(ROOT/'evidence/seed-generalization.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),generalized.splitlines(True),fromfile='seed0',tofile='parameterized-seed')))
for name in ('confirm_joint_augmentation.py','evaluate_joint_confirmation.py'):
    shutil.copy2(WS/'work'/name,ROOT/'src'/name)


def execute(stage,script,timeout):
    command=[sys.executable,'-u',str(ROOT/'src'/script)];tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
        'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-5000:]);sys.exit(code)


execute('remaining-seeds','run_joint_confirmation.py',900)
execute('locked-evaluation','evaluate_joint_confirmation.py',180)
