"""One-time train-only calibration and paired validation-only experiment."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
import torch.nn.functional as F
import loss_calibration_runtime as rt

ROOT=rt.ROOT
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
BASE_WEIGHTS=PROTOCOL['baseline_weights']
training=rt.training


def write_json(path,value):
    training.write_json(path,value)


def calibrate():
    records=[];vectors=[]
    started=time.monotonic()
    directory=ROOT/'calibration';directory.mkdir(exist_ok=False)
    for seed in PROTOCOL['calibration']['initialization_seeds']:
        training.seed_all(seed)
        model=rt.new_encoder();model.train()
        original_parameters={name:p.detach().cpu().clone() for name,p in model.named_parameters()}
        encoder,augmentation=rt.parameter_groups(model)
        with torch.random.fork_rng(devices=[0]):
            for draw in range(PROTOCOL['calibration']['draws_per_initialization']):
                training.seed_all(610000+1000*seed+draw)
                h,x_hat,sampled=rt.forward_encoder(model)
                losses=rt.loss_terms(model,h,x_hat)
                encS=rt.flat_gradients(.5*losses['S'],encoder)
                encF=rt.flat_gradients(.5*losses['F'],encoder)
                augS=rt.flat_gradients(.5*losses['S'],augmentation).cpu()
                augF=rt.flat_gradients(.5*losses['F'],augmentation).cpu()
                augA=rt.flat_gradients(losses['A'],augmentation).cpu()
                row={'seed':seed,'draw':draw,'draw_rng_seed':610000+1000*seed+draw,
                     'raw_loss':{k:float(v.detach()) for k,v in losses.items()},
                     'encoder_S_norm':rt.vector_norm(encS),'encoder_F_norm':rt.vector_norm(encF),
                     'encoder_S_F_cosine':rt.cosine(encS,encF),
                     'augmentation_S_norm':rt.vector_norm(augS),'augmentation_F_norm':rt.vector_norm(augF),
                     'augmentation_A_norm':rt.vector_norm(augA),
                     'augmentation_S_F_cosine':rt.cosine(augS,augF),
                     'augmentation_reconstruction_A_cosine_before':rt.cosine(augS+augF,augA)}
                row['encoder_ratio_before']=row['encoder_S_norm']/row['encoder_F_norm']
                row['augmentation_ratio_before']=rt.vector_norm(augS+augF)/rt.vector_norm(augA)
                records.append(row);vectors.append({'S':augS,'F':augF,'A':augA})
                if draw==0:
                    torch.save({'state_dict':training.cpu_state(model),'initialization_seed':seed,
                        'optimizer_updates':0},directory/f'initial-seed-{seed:02d}.pt')
                print('CALIBRATION '+json.dumps(row),flush=True)
                del h,x_hat,sampled,losses,encS,encF
                model.h=None
        assert all(torch.equal(p.detach().cpu(),original_parameters[name]) for name,p in model.named_parameters())
        del model,original_parameters,encoder,augmentation
        torch.cuda.empty_cache()
    lower,upper=PROTOCOL['calibration']['multiplier_clip']
    feature_raw=float(np.median([v['encoder_ratio_before'] for v in records]))
    feature=float(np.clip(feature_raw,lower,upper))
    aug_raw=float(np.median([rt.vector_norm(v['S']+feature*v['F'])/rt.vector_norm(v['A']) for v in vectors]))
    aug=float(np.clip(aug_raw,lower,upper))
    weights={'S':.5,'F':.5*feature,'A':aug}
    for row,v in zip(records,vectors):
        row['encoder_ratio_after']=row['encoder_ratio_before']/feature
        row['augmentation_ratio_after']=rt.vector_norm(v['S']+feature*v['F'])/(aug*rt.vector_norm(v['A']))
        row['augmentation_reconstruction_A_cosine_after']=rt.cosine(v['S']+feature*v['F'],v['A'])
    result={'baseline_weights':BASE_WEIGHTS,'calibrated_weights':weights,
            'feature_multiplier_raw':feature_raw,'feature_multiplier':feature,
            'augmentation_multiplier_raw':aug_raw,'augmentation_multiplier':aug,
            'clip_applied':feature!=feature_raw or aug!=aug_raw,
            'encoder_ratio_before_median':float(np.median([r['encoder_ratio_before'] for r in records])),
            'encoder_ratio_after_median':float(np.median([r['encoder_ratio_after'] for r in records])),
            'augmentation_ratio_before_median':float(np.median([r['augmentation_ratio_before'] for r in records])),
            'augmentation_ratio_after_median':float(np.median([r['augmentation_ratio_after'] for r in records])),
            'initial_parameters_unchanged':True,'optimizer_updates_during_calibration':0,
            'test_or_validation_labels_used_for_calibration':False,'records':records,
            'elapsed_seconds':time.monotonic()-started}
    torch.save(vectors,directory/'augmentation-gradients.pt')
    write_json(ROOT/'calibration.json',result)
    print('CALIBRATED_WEIGHTS '+json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True)


def probability_stats(model,h):
    with torch.no_grad():
        probability=model.gcn.last_probabilities
        target=model.gcn.last_targets.bool()
        return {'node_feature_std':float(h.std(0).mean()),
                'original_edge_probability_mean':float(probability[target].mean()),
                'new_edge_probability_mean':float(probability[~target].mean()),
                'probability_min':float(probability.min()),'probability_max':float(probability.max()),
                'saturated_fraction':float(((probability<1e-4)|(probability>1-1e-4)).float().mean())}


def pretrain(seed,condition,epochs,stage):
    dest=ROOT/stage/f'seed-{seed:02d}'/condition
    dest.mkdir(parents=True,exist_ok=False)
    calibration=json.loads((ROOT/'calibration.json').read_text())
    weights=BASE_WEIGHTS if condition=='baseline' else calibration['calibrated_weights']
    initial=torch.load(ROOT/f'calibration/initial-seed-{seed:02d}.pt',map_location='cpu')
    training.seed_all(seed)
    model=rt.new_encoder();model.load_state_dict(initial['state_dict'])
    training.seed_all(900000+seed)
    optimizer=torch.optim.Adam(model.parameters(),lr=1e-4,weight_decay=1e-5)
    config={'condition':condition,'seed':seed,'weights':weights,'epochs':epochs,
            'training_rng_seed':900000+seed,'optimizer':'Adam lr1e-4 weight_decay1e-5',
            'selection':'minimum own weighted SSL loss, earlier ties; saved weights are those scored before update',
            'raw_loss_definitions':PROTOCOL['raw_losses'],'engineering_extension':True,
            'test_metrics_computed':False}
    write_json(dest/'pretrain-config.json',config)
    best=float('inf');best_epoch=0;best_state=None;step_times=[];snapshots=[]
    first_update=None;started=time.monotonic()
    with (dest/'pretrain-history.jsonl').open('x') as history:
        for epoch in range(1,epochs+1):
            torch.cuda.synchronize();tick=time.perf_counter()
            model.train();optimizer.zero_grad(set_to_none=True)
            h,x_hat,sampled=rt.forward_encoder(model,epoch)
            terms=rt.loss_terms(model,h,x_hat)
            total=sum(weights[k]*v for k,v in terms.items())
            assert torch.isfinite(total)
            row={'epoch':epoch,'weighted_total':float(total.detach()),
                 'reference_total':sum(BASE_WEIGHTS[k]*float(v.detach()) for k,v in terms.items()),
                 'raw_loss':{k:float(v.detach()) for k,v in terms.items()},**probability_stats(model,h)}
            if epoch in (1,epochs):
                row['gradient_diagnostics']=rt.diagnostics(model,terms,weights)
                snapshots.append(row)
            if row['weighted_total']<best:
                best=row['weighted_total'];best_epoch=epoch;best_state=training.cpu_state(model)
            total.backward()
            if epoch in (1,epochs):
                assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
            if epoch==1:
                before={name:p.detach().clone() for name,p in model.gcn.named_parameters()}
                gradient_norms={name:float(p.grad.norm()) if p.grad is not None else None for name,p in model.gcn.named_parameters()}
                assert all(v is not None and v>0 for v in gradient_norms.values())
            optimizer.step()
            if epoch==1:
                update={name:float((p.detach()-before[name]).abs().max()) for name,p in model.gcn.named_parameters()}
                assert all(v>0 for v in update.values())
                first_update={'gradient_norms':gradient_norms,'parameter_max_abs_update':update}
                del before
            torch.cuda.synchronize()
            if epoch>=6 and epoch not in (1,epochs):step_times.append(time.perf_counter()-tick)
            row['best_epoch']=best_epoch
            history.write(json.dumps(row)+'\n');history.flush()
            if epoch<=2 or epoch%25==0 or epoch==epochs:
                print('PRETRAIN '+json.dumps({'stage':stage,'seed':seed,'condition':condition,**row}),flush=True)
    assert all(torch.isfinite(p).all() for p in model.parameters())
    torch.save({'state_dict':training.cpu_state(model),'config':config,'epoch':epochs},dest/'last-pretrained.pt')
    torch.save({'state_dict':best_state,'config':config,'best_epoch':best_epoch,'best_total_loss':best},dest/'pretrained.pt')
    model.load_state_dict(best_state);model.eval()
    with torch.no_grad(),torch.random.fork_rng(devices=[0]):
        training.seed_all(720000+seed)
        expected=rt.forward_encoder(model,best_epoch)[0].detach().clone()
    restored=rt.new_encoder();restored.load_state_dict(torch.load(dest/'pretrained.pt',map_location='cpu')['state_dict']);restored.eval()
    with torch.no_grad(),torch.random.fork_rng(devices=[0]):
        training.seed_all(720000+seed)
        actual=rt.forward_encoder(restored,best_epoch)[0]
    error=float((expected-actual).abs().max());assert error<1e-5
    result={'seed':seed,'condition':condition,'weights':weights,'epochs':epochs,'best_epoch':best_epoch,
            'initial':snapshots[0],'last':snapshots[-1],'first_update':first_update,
            'all_losses_and_parameters_finite':True,'checkpoint_reload_embedding_max_error':error,
            'median_training_step_seconds':float(np.median(step_times)),
            'elapsed_seconds':time.monotonic()-started,'test_metrics_computed':False}
    write_json(dest/'pretrain-result.json',result)
    print('PRETRAIN_COMPLETE '+json.dumps({k:v for k,v in result.items() if k not in ('initial','last','first_update')}),flush=True)
    return result


def short():
    results=[]
    for seed in (0,1,2):
        for condition in ('baseline','calibrated'):
            results.append(pretrain(seed,condition,50,'short'))
            torch.cuda.empty_cache()
    calibrated=[v for v in results if v['condition']=='calibrated']
    calibration=json.loads((ROOT/'calibration.json').read_text())
    balanced=all(.5<=calibration[key]<=2 for key in ('encoder_ratio_after_median','augmentation_ratio_after_median'))
    stable=all(all(v['last']['raw_loss'][k]<=2*v['initial']['raw_loss'][k] for k in ('S','F','A')) for v in calibrated)
    noncollapsed=all(v['last']['node_feature_std']>=.1*v['initial']['node_feature_std'] for v in calibrated)
    finite=all(v['all_losses_and_parameters_finite'] for v in results)
    paired=[]
    for seed in (0,1,2):
        a,b=[v for v in results if v['seed']==seed]
        diffs={k:abs(a['initial']['raw_loss'][k]-b['initial']['raw_loss'][k]) for k in ('S','F','A')}
        assert max(diffs.values())<1e-5
        paired.append({'seed':seed,'first_forward_raw_loss_difference':diffs})
    result={'pass':balanced and stable and noncollapsed and finite,'balanced_initialization':balanced,
            'stable_raw_losses':stable,'noncollapsed_representations':noncollapsed,'finite':finite,
            'paired_initialization_check':paired,'results':results,'test_metrics_computed':False}
    write_json(ROOT/'short-summary.json',result)
    print('SHORT_GATE '+json.dumps({k:v for k,v in result.items() if k!='results'}),flush=True)


def classify(seed,condition):
    sys.path.insert(0,str(rt.DELIVERY/'src'))
    from fairness_metrics import evaluate,generalized_degree
    dest=ROOT/'full'/f'seed-{seed:02d}'/condition
    checkpoint=torch.load(dest/'pretrained.pt',map_location='cpu')
    values=np.load(rt.DELIVERY/f'locked-predictions/p3-seed-{seed:02d}.npz')
    degree=generalized_degree(values['edge_index'],rt.N,1)
    split={k:torch.as_tensor(values[k+'_ids'],device=training.DEVICE) for k in ('train','val')}
    truth=values['labels'];labels=torch.as_tensor(truth,device=training.DEVICE)
    assert np.array_equal(truth,rt.data.y.numpy())
    training.seed_all(100+seed)
    model=training.Classifier(rt.new_encoder()).to(training.DEVICE)
    model.encoder.load_state_dict(checkpoint['state_dict'])
    for parameter in model.encoder.gcn.parameters():parameter.requires_grad_(False)
    assert model.encoder.gcn.learn_augmentation
    sampler_before={name:p.detach().clone() for name,p in model.encoder.gcn.named_parameters()}
    initial_head_sha=hashlib.sha256(b''.join(v.detach().cpu().numpy().tobytes() for v in model.head.parameters())).hexdigest()
    training.seed_all(810000+seed)
    optimizer=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=1e-4,weight_decay=1e-5)
    config={'seed':seed,'condition':condition,'max_epochs':500,'patience':100,'lr':1e-4,'weight_decay':1e-5,
            'classifier_initialization_seed':100+seed,'training_rng_seed':810000+seed,
            'selection':'strict validation accuracy, earlier ties; no EO selection',
            'classification_loss':'public probability-input CE','augmentation_parameters':'frozen, trained probabilities retained',
            'head_initial_sha256':initial_head_sha,'test_metrics_computed':False,
            'ssl_weights':checkpoint['config']['weights']}
    write_json(dest/'classifier-config.json',config)
    best=-1.0;best_epoch=0;best_state=None;started=time.monotonic()
    with (dest/'classification-history.jsonl').open('x') as history:
        for epoch in range(1,501):
            model.train();optimizer.zero_grad(set_to_none=True)
            logits=model(rt.active,epoch)
            loss=F.cross_entropy(logits.softmax(1)[split['train']],labels[split['train']])
            assert torch.isfinite(loss)
            loss.backward()
            if epoch==1:
                assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
                assert all(p.grad is None for p in model.encoder.gcn.parameters())
            optimizer.step()
            valid_logits=training.evaluate(model,rt.active,epoch,100000+seed)
            prediction=valid_logits.argmax(1)
            accuracy=float((prediction[split['val']]==labels[split['val']]).float().mean())
            if accuracy>best:
                best=accuracy;best_epoch=epoch;best_state=training.cpu_state(model)
            row={'epoch':epoch,'training_loss':float(loss.detach()),'validation_accuracy':accuracy,'best_epoch':best_epoch}
            history.write(json.dumps(row)+'\n');history.flush()
            if epoch<=2 or epoch%50==0:
                print('CLASSIFICATION '+json.dumps({'seed':seed,'condition':condition,**row}),flush=True)
            if epoch-best_epoch>=100:break
    assert all(torch.equal(p.detach(),sampler_before[name]) for name,p in model.encoder.gcn.named_parameters())
    model.load_state_dict(best_state)
    logits=training.evaluate(model,rt.active,best_epoch,100000+seed)
    prediction=logits.argmax(1).cpu().numpy();ids=values['val_ids']
    metric=evaluate(prediction,truth,degree,ids,.2,'reference_percentile')
    assert not metric['missing_classes']
    recalls=np.array([[v['low_recall'],v['high_recall']] for v in metric['per_class']])
    selected={'accuracy':100*float(np.mean(prediction[ids]==truth[ids])),'SP':metric['SP'],'EO':metric['EO_strict'],
              'macro_worst_group_recall':100*float(recalls.min(1).mean()),'minimum_class_group_recall':100*float(recalls.min()),
              'per_class':metric['per_class'],'low_n':metric['low_n'],'high_n':metric['high_n'],'thresholds':metric['thresholds']}
    checkpoint={'state_dict':best_state,'config':config,'best_epoch':best_epoch,'evaluation_seed':100000+seed,
                'split':{k:torch.as_tensor(values[k+'_ids']) for k in ('train','val','test')}}
    torch.save(checkpoint,dest/'classifier-best.pt')
    reloaded=training.Classifier(rt.new_encoder()).to(training.DEVICE)
    reloaded.load_state_dict(torch.load(dest/'classifier-best.pt',map_location='cpu')['state_dict'])
    actual=training.evaluate(reloaded,rt.active,best_epoch,100000+seed).argmax(1).cpu().numpy()
    assert np.array_equal(prediction[ids],actual[ids])
    np.savez_compressed(dest/'validation-only.npz',validation_ids=ids,labels=truth[ids],degree=degree[ids],predictions=prediction[ids],
                        probabilities=logits.softmax(1).detach().cpu().numpy()[ids])
    result={'seed':seed,'condition':condition,'selected':selected,'best_epoch':best_epoch,'epochs_run':epoch,
            'head_initial_sha256':initial_head_sha,'sampler_unchanged_during_classification':True,
            'reload_validation_predictions_identical':True,'test_metrics_computed':False,'elapsed_seconds':time.monotonic()-started}
    write_json(dest/'classification-result.json',result)
    print('CLASSIFICATION_COMPLETE '+json.dumps(result),flush=True)
    return result


def full():
    assert json.loads((ROOT/'short-summary.json').read_text())['pass']
    results=[]
    for condition in ('baseline','calibrated'):
        pretrain(0,condition,500,'full')
        torch.cuda.empty_cache()
        results.append(classify(0,condition))
        torch.cuda.empty_cache()
    assert results[0]['head_initial_sha256']==results[1]['head_initial_sha256']
    write_json(ROOT/'full-summary.json',{'results':results,'test_metrics_computed':False})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['calibrate','short','full']);args=parser.parse_args()
    {'calibrate':calibrate,'short':short,'full':full}[args.stage]()
