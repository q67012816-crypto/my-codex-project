"""Validation gate first; no test access until its decision is persisted."""
import json
from pathlib import Path
import sys
import numpy as np
import torch
import loss_calibration_runtime as rt

ROOT=rt.ROOT
sys.path.insert(0,str(rt.DELIVERY/'src'))
from fairness_metrics import evaluate,generalized_degree
validation=[]
for seed in (0,1,2):
    for condition in ('frozen','joint'):
        row=json.loads((ROOT/f'full/seed-{seed:02d}/{condition}/result.json').read_text())
        validation.append({'seed':seed,'condition':condition,'selected':row['selected'],'best_epoch':row['best_epoch']})
keys=('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall')
summary={condition:{key:float(np.mean([v['selected'][key] for v in validation if v['condition']==condition])) for key in keys} for condition in ('frozen','joint')}
base,new=summary['frozen'],summary['joint']
pairs=[([v['selected'] for v in validation if v['seed']==seed]) for seed in (0,1,2)]
accuracy_safe=all(b['accuracy']>=a['accuracy']-.5 for a,b in pairs)
improved_seeds=sum(b['EO']<a['EO'] for a,b in pairs)
gate=(new['EO']<=.9*base['EO'] and new['macro_worst_group_recall']>=base['macro_worst_group_recall']-1e-10
      and new['minimum_class_group_recall']>=base['minimum_class_group_recall']-1e-10 and accuracy_safe and improved_seeds>=2)
decision={'pass':gate,'accuracy_safe_each_seed':accuracy_safe,'EO_improved_seeds':improved_seeds,
          'summary':summary,'results':validation,'test_results_used_for_decision':False,'test_metrics_computed':False}
(ROOT/'validation-decision.json').write_text(json.dumps(decision,indent=2))
print('VALIDATION_DECISION '+json.dumps({k:v for k,v in decision.items() if k!='results'}),flush=True)
if not gate:
    print('TEST_NOT_RUN_VALIDATION_GATE_FAILED',flush=True);sys.exit(0)
(ROOT/'locked-primary.json').write_text(json.dumps({'primary':'joint','seeds':[0,1,2],'selection':'validation gate before test','test_based_reselection':False},indent=2))
records=[]
for seed in (0,1,2):
    values=np.load(rt.DELIVERY/f'locked-predictions/p3-seed-{seed:02d}.npz')
    degree=generalized_degree(values['edge_index'],rt.N,1)
    for condition in ('frozen','joint'):
        directory=ROOT/f'full/seed-{seed:02d}/{condition}'
        checkpoint=torch.load(directory/'classifier-best.pt',map_location='cpu')
        model=rt.training.Classifier(rt.new_encoder()).to(rt.training.DEVICE)
        model.load_state_dict(checkpoint['state_dict'])
        logits=rt.training.evaluate(model,rt.active,checkpoint['best_epoch'],100000+seed)
        prediction=logits.argmax(1).cpu().numpy();probability=logits.softmax(1).cpu().numpy()
        archived=np.load(directory/'validation-only.npz')
        assert np.array_equal(prediction[values['val_ids']],archived['predictions'])
        metric=evaluate(prediction,values['labels'],degree,values['test_ids'],.2,'reference_percentile')
        assert not metric['missing_classes']
        row={'seed':seed,'condition':condition,'accuracy':100*float(np.mean(prediction[values['test_ids']]==values['labels'][values['test_ids']])),
             'SP':metric['SP'],'EO':metric['EO_strict'],'detail':metric,'validation_prediction_matches_archived':True}
        np.savez_compressed(directory/'locked-predictions.npz',predictions=prediction,probabilities=probability,
            labels=values['labels'],degree=degree,edge_index=values['edge_index'],
            train_ids=values['train_ids'],val_ids=values['val_ids'],test_ids=values['test_ids'])
        records.append(row)
        print('LOCKED_TEST '+json.dumps({k:v for k,v in row.items() if k!='detail'}),flush=True)
        del model,logits;torch.cuda.empty_cache()
summary={condition:{key:{'mean':float(np.mean([v[key] for v in records if v['condition']==condition])),
    'std_ddof0':float(np.std([v[key] for v in records if v['condition']==condition],ddof=0))}
    for key in ('accuracy','SP','EO')} for condition in ('frozen','joint')}
(ROOT/'locked-test-results.json').write_text(json.dumps({'summary':summary,'results':records,
    'primary':'joint','seed_count':3,'test_based_reselection':False},indent=2))
print('LOCKED_TEST_SUMMARY '+json.dumps(summary),flush=True)
