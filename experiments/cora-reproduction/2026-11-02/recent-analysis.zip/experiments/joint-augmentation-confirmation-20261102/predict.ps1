param([ValidateSet(0,1,2)][int]$Seed = 0, [ValidateSet('frozen','joint')][string]$Condition = 'joint')
$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/predict_joint_confirmation.py').Replace('\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath --seed $Seed --condition $Condition
if ($LASTEXITCODE -ne 0) { throw "Prediction verification failed, exit code $LASTEXITCODE" }
