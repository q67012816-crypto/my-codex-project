import hashlib
import json
from pathlib import Path
import shutil

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/loss-calibration-20261102-01')
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir()
architecture=WS/'outputs/augmentation-path-cost-20261102/src/gated_models.py'
shutil.copy2(architecture,ROOT/'src/gated_models.py')
shutil.copy2(Path(__file__),ROOT/'src'/Path(__file__).name)
protocol={'date':'2026-11-02 Asia/Seoul','question':'Can one-time gradient scaling balance task influence without multiplying a global feature coefficient by the sampler-only ratio?',
 'scope':'static train-only engineering calibration of reconstructed learnable augmentation; not GradNorm/PCGrad implementation and not verified original-paper training',
 'only_changed_factor':'fixed loss weights after initialization calibration',
 'architecture_sha256':hashlib.sha256(architecture.read_bytes()).hexdigest(),
 'architecture':'4layers4heads64dim, independent structural QK, current cumulative neighborhood/Jaccard, bounded trainable augmentation and documented zero-row surrogate',
 'raw_losses':{'S':'sum_p ||cos(h)-logM[p]||^2/(p*N*N)',
               'F':'mean squared feature error',
               'A':'2*sum_upper BCEWithLogits(augmentation_logits,original_edge)/(N*N)'},
 'baseline_weights':{'S':.5,'F':.5,'A':1.0},
 'calibration':{'initialization_seeds':[0,1,2],'draws_per_initialization':4,
    'encoder_reference':'all encoder parameters except feature decoder and augmentation network; unused gradients treated as0',
    'sampler_reference':'all augmentation GCN/MLP parameters',
    'feature_multiplier':'median ||grad_encoder(.5*S)|| / ||grad_encoder(.5*F)|| over12 fixed train-mode draws',
    'augmentation_multiplier':'median ||grad_aug(.5*S)+feature_multiplier*grad_aug(.5*F)|| / ||grad_aug(A)|| over same12 draws',
    'multiplier_clip':[.1,100.0],'common_across_seeds':True,'optimizer_updates_during_calibration':0,
    'rng_handling':'fork/restore RNG; training starts at prescribed independent common seed'},
 'short_run':{'seeds':[0,1,2],'epochs':50,'conditions':['baseline','calibrated'],'lr':1e-4,'weight_decay':1e-5},
 'extension_gate':'all short runs finite; median initial calibrated encoder S/F and sampler reconstruction/A norm ratios in[.5,2]; calibrated terminal raw S/F/A each<=2*own initial; no representation collapse relative to own initialization',
 'extended_seed0':{'pretrain_epochs':500,'pretrain_selection':'lowest own weighted SSL loss, earlier ties',
    'classification_max_epochs':500,'classification_patience':100,'classification_lr':1e-4,'weight_decay':1e-5,
    'augmentation_parameters':'frozen for classification in both arms',
    'classifier_initialization_seed':'100+seed, same head initialization and sampler stream for both arms',
    'classifier_selection':'strict validation accuracy, earlier ties'},
 'evaluation':'validation only, same r1 percentile grouping and per-class absolute EO; no test-based weight choices',
 'test_metrics_computed':False,'not_added':['PCGrad','dynamic loss weights','explicit fairness penalty','different architecture or split']}
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
print(ROOT)
