"""Replay the archived experiment in a fresh D: directory; preserves all old runs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ARTIFACT=Path(__file__).resolve().parent.parent
stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
ROOT=Path('/mnt/d/cgt-experiment')/('loss-calibration-replay-'+stamp)
dependencies=json.loads((ARTIFACT/'dependency-manifest.json').read_text())
for row in dependencies:
    path=Path(row['path'])
    assert path.is_file(),f'Missing existing dependency: {path}'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],f'Dependency changed: {path}'
ROOT.mkdir(exist_ok=False);(ROOT/'src').mkdir()
for name in ('run_loss_calibration.py','loss_calibration_runtime.py','gated_models.py'):
    shutil.copy2(ARTIFACT/'src'/name,ROOT/'src'/name)
shutil.copy2(ARTIFACT/'protocol.json',ROOT/'protocol.json')
print('NEW_EXPERIMENT_DIRECTORY '+str(ROOT),flush=True)
for stage,timeout in [('calibrate',180),('short',300),('full',600)]:
    if stage=='full' and not json.loads((ROOT/'short-summary.json').read_text())['pass']:
        print('FULL_SKIPPED_SHORT_GATE_FAILED',flush=True);break
    command=[sys.executable,'-u',str(ROOT/'src/run_loss_calibration.py'),stage]
    tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
            'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-4500:]);sys.exit(code)
print('COMPLETE '+str(ROOT),flush=True)
