"""Independently audit validation CSV-equivalent predictions and archive deliverables."""
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import numpy as np

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/loss-calibration-20261102-01')
OUT=WS/'outputs/loss-calibration-20261102'
assert not OUT.exists()
cal=json.loads((ROOT/'calibration.json').read_text())
short=json.loads((ROOT/'short-summary.json').read_text())
full=json.loads((ROOT/'full-summary.json').read_text())
for stage in ('calibrate','short','full'):
    assert json.loads((ROOT/f'{stage}.exit.json').read_text())['exit_code']==0
audits=[]
for result in full['results']:
    source=ROOT/'full/seed-00'/result['condition']/'validation-only.npz'
    v=np.load(source)
    truth,pred,degree=v['labels'],v['predictions'],v['degree']
    q20,q80=np.percentile(degree,[20,80]);low=degree<=q20;high=degree>q80
    recalls=[];eo=[];sp=[]
    for label in np.unique(truth):
        a=low&(truth==label);b=high&(truth==label)
        assert a.any() and b.any()
        lo=np.mean(pred[a]==label);hi=np.mean(pred[b]==label)
        recalls.append([lo,hi]);eo.append(abs(lo-hi))
        sp.append(abs(np.mean(pred[low]==label)-np.mean(pred[high]==label)))
    audit={'condition':result['condition'],'accuracy':100*float(np.mean(pred==truth)),
           'SP':100*float(np.mean(sp)),'EO':100*float(np.mean(eo)),
           'macro_worst_group_recall':100*float(np.min(recalls,axis=1).mean()),
           'minimum_class_group_recall':100*float(np.min(recalls)),'validation_n':len(pred),
           'low_n':int(low.sum()),'high_n':int(high.sum()),'thresholds':[float(q20),float(q80)]}
    for key in ('accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall'):
        assert abs(audit[key]-result['selected'][key])<1e-10
    audits.append(audit)
shutil.copytree(ROOT,OUT)
shutil.copy2(WS/'work/replay_loss_calibration.py',OUT/'src/replay_loss_calibration.py')
shutil.copy2(Path(__file__),OUT/'src/export_loss_calibration.py')
dep_paths=[WS/'outputs/fairness-recheck-20261101/official-loss-models/src/train_cora.py',
           WS/'outputs/fairness-recheck-20261101/official-loss-models/src/aligned_models.py',
           WS/'outputs/fairness-recheck-20261101/official-loss-models/cora_k3_clusters5_official_rules.pt',
           WS/'outputs/reproduction-audit-20261102/cache-for-inference.pt',
           WS/'outputs/reproduction-audit-20261102/src/fairness_metrics.py',
           Path('/root/cgt/repo/gnnutils.py'),Path('/root/cgt/repo/util.py'),
           Path('/root/cgt/repo/original_datasets/planetoid/cora/processed/data.pt'),
           *[WS/f'outputs/reproduction-audit-20261102/locked-predictions/p3-seed-{s:02d}.npz' for s in (0,1,2)]]
deps=[{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size} for path in dep_paths]
(OUT/'dependency-manifest.json').write_text(json.dumps(deps,indent=2))
(OUT/'independent-validation-audit.json').write_text(json.dumps(audits,indent=2))
environment={'python':subprocess.check_output([str(Path('/root/miniconda3/envs/cgt/bin/python')),'--version'],text=True).strip(),
             'packages':{name:importlib.metadata.version(name) for name in ('torch','dgl','torch-geometric','numpy','scipy','pyro-ppl')},
             'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True).strip(),
             'LD_LIBRARY_PATH':'/root/miniconda3/envs/cgt/lib','CONDA_PREFIX':'/root/miniconda3/envs/cgt',
             'official_commit':subprocess.check_output(['git','-C','/root/cgt/repo','rev-parse','HEAD'],text=True).strip()}
(OUT/'environment.json').write_text(json.dumps(environment,indent=2))
with (OUT/'validation-comparison.csv').open('w',newline='') as stream:
    keys=['condition','accuracy','SP','EO','macro_worst_group_recall','minimum_class_group_recall','validation_n','low_n','high_n']
    writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader()
    writer.writerows([{key:row[key] for key in keys} for row in audits])
for result in full['results']:
    npz=np.load(OUT/'full/seed-00'/result['condition']/'validation-only.npz')
    with (OUT/f"validation-predictions-{result['condition']}.csv").open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['node_id','label','prediction','original_degree'])
        writer.writerows(zip(npz['validation_ids'],npz['labels'],npz['predictions'],npz['degree']))
ps1='''$ErrorActionPreference = 'Stop'
$scriptPath = (Join-Path $PSScriptRoot 'src/replay_loss_calibration.py').Replace('\\','/')
$convertedPath = & wsl.exe -d Ubuntu-D -u root --exec /usr/bin/wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0 -or -not $convertedPath) { throw 'WSL path conversion failed' }
$wslPath = $convertedPath.Trim()
& wsl.exe -d Ubuntu-D -u root -- env LD_LIBRARY_PATH=/root/miniconda3/envs/cgt/lib CONDA_PREFIX=/root/miniconda3/envs/cgt PYTHONDONTWRITEBYTECODE=1 /root/miniconda3/envs/cgt/bin/python -u $wslPath
if ($LASTEXITCODE -ne 0) { throw "Replay failed, exit code $LASTEXITCODE" }
'''
(OUT/'replay.ps1').write_text(ps1)
base,scaled=audits
table='\n'.join(f"| {v['condition']} | {v['accuracy']:.2f} | {v['SP']:.2f} | {v['EO']:.2f} | {v['macro_worst_group_recall']:.2f} | {v['minimum_class_group_recall']:.2f} |" for v in audits)
shorttable='\n'.join(f"| {v['seed']} | {v['condition']} | {v['last']['raw_loss']['S']:.6f} | {v['last']['raw_loss']['F']:.6f} | {v['last']['raw_loss']['A']:.8f} | {v['last']['gradient_diagnostics']['encoder_structure_to_feature']:.3f} | {v['last']['gradient_diagnostics']['augmentation_reconstruction_to_regularizer']:.3f} |" for v in short['results'])
report=f'''# 一次性损失梯度标定：真实运行结果

已完成12次初始化梯度测量、3种子×2条件×50轮短流程，以及种子0两条件各500轮预训练和后续分类。三个阶段退出码均为0。本轮仅改变损失权重；两条件共用已有可学习增强实验架构、缓存、数据划分、初始化和随机采样流。历史源码、结果和检查点保留。

**本轮结论：不将这套标定权重设为新默认。** 种子0验证EO变差，按类最差组召回均值也下降。梯度量级的初始化平衡没有转化为公平性改善，未扩大长训练批次。

这是一项工程扩展，尚不能视为作者原始实现的复现。此次结果全部来自验证集，不能与论文测试集EO=4.26直接比较，也不是10种子的均值。

## 如何标定

记S为3个结构重构误差的平均值（每项除以N²），F为特征MSE，A为增强概率相对于原邻接的BCE（按全N²归约、对称候选上三角计两次）。原权重为0.5S+0.5F+A。

1. 在3个初始化、每个4次独立的训练模式采样上，前向并分别测量梯度，期间不执行优化器更新。共享编码器参考参数排除特征解码器和增强网络。
2. 用中位数rF=median(‖∇enc(0.5S)‖/‖∇enc(0.5F)‖)={cal['feature_multiplier']:.8f}，提高特征系数。
3. 在增强网络参数上，用rA=median(‖∇aug(0.5S)+rF∇aug(0.5F)‖/‖∇aug A‖)={cal['augmentation_multiplier']:.8f}，标定增强正则项。
4. 固定权重，不在每轮重新测量或更新。预设乘数范围[0.1,100]，本轮没有触及边界。

最终固定目标：**L=0.5S+{cal['calibrated_weights']['F']:.8f}F+{cal['calibrated_weights']['A']:.8f}A**。系数依赖上述精确归约方式，不能照搬到论文求和式或候选边平均BCE中。没有将增强网络上的120–232倍差距当作整个编码器的系数。

初始化编码器结构/特征梯度中位比：{cal['encoder_ratio_before_median']:.4f}→{cal['encoder_ratio_after_median']:.4f}；增强网络重构/正则梯度中位比：{cal['augmentation_ratio_before_median']:.4f}→{cal['augmentation_ratio_after_median']:.4f}。这是原始损失梯度的量级标定，不能保证Adam参数更新大小相等，也不能消除方向冲突。

## 50轮短流程

| 种子 | 条件 | S50 | F50 | A50 | 编码器S/F梯度比 | 增强重构/A梯度比 |
|---|---|---:|---:|---:|---:|---:|
{shorttable}

六个流程均有限、增强网络全部8个参数张量存在有限非零梯度和实际更新；两条件首次前向的三项原始损失一致；表示未塌缩；检查点恢复后固定采样下的嵌入最大误差为0。

新权重更重视特征重构，结构重构误差相应更高。第50轮编码器梯度比约1，但增强正则梯度已占优，因此初始化平衡不等于训练全过程平衡；不能只展示初始梯度就宣称问题解决。

## 种子0完整对照：验证集

| 条件 | 准确率% | SP↓ | EO↓ | 按类最差组召回均值%↑ | 全部类组最小召回%↑ |
|---|---:|---:|---:|---:|---:|
{table}

标定减原权重：准确率{scaled['accuracy']-base['accuracy']:+.2f}个百分点，SP{scaled['SP']-base['SP']:+.2f}个百分点，EO{scaled['EO']-base['EO']:+.2f}个百分点。类别组召回详情在full/seed-00/*/classification-result.json。

两条件均从各自500轮中按最低自身加权SSL目标选择预训练状态；保存的是产生该目标的更新前权重。两种目标的总损失数值不能直接横向比较。分类最多500轮、100轮耐心，均保留公共实现的概率输入交叉熵；仅按验证准确率严格提高选轮次，不按EO选择。分类阶段冻结增强网络参数并保留各自学到的概率，其余编码器和相同初始分类头参与训练。两条件分类头初始SHA256一致，训练/评估采样种子相同。

验证集541个节点，r=1，使用原始简单图度数；验证集内20/80百分位阈值分组，低组≤q20、高组>q80。低组{base['low_n']}、高组{base['high_n']}，阈值{base['thresholds']}。EO为7类条件召回差绝对值的宏平均×100；本次没有缺失类别。CSV独立复算与运行报告一致，没有计算本轮测试指标。

一次验证种子只能说明本次效果，不能证明稳定降低EO。原权重对照也使用此前的实验性可学习增强、概率BCE和新的分类头初始化，不能与历史固定增强结果拼成一个因果对照。

## 计算开销与复查

标定阶段12次测量本体耗时{cal['elapsed_seconds']:.2f}秒，不含进程启动和数据载入；完整阶段耗时见各exit.json。正常训练仍将三项按固定权重求和、只做一次backward。短流程及第500轮记录诊断时额外做了分项梯度计算；这些诊断不参与动态调权，部署训练可关闭。顺序训练计时只作运行记录，不据此宣称精确的速度提升。

所有src、日志、退出状态、配置、初始权重、预训练检查点、分类最佳检查点、验证预测和逐节点CSV均保存在本目录。independent-validation-audit.json为CSV等价数组的独立复算；dependency-manifest.json记录复用缓存和源码的SHA256；environment.json记录当前环境。

在本机PowerShell执行`./replay.ps1`会先检查依赖指纹，再在D:/cgt-experiment创建新的时间戳目录，重新执行同样的标定、短流程和有条件的完整种子0对照，绝不覆盖本次运行。它复用Ubuntu-D和现有cgt环境、现有数据及上述缓存路径，不安装依赖、不下载数据。CUDA图算子的独立重训仍可能有微小数值差异；同一检查点固定采样的预测已在本轮验证恢复一致。
'''
(OUT/'report.md').write_text(report,encoding='utf-8')
manifest=[{'path':str(path.relative_to(OUT)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
          for path in sorted(OUT.rglob('*')) if path.is_file()]
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'files':len(manifest)+1,'independent_validation_audit':audits},indent=2),flush=True)
