"""Execute bounded stages, with full logs and explicit exit status."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
ROOT=Path('/mnt/d/cgt-experiment/loss-calibration-20261102-01')
for name in ('loss_calibration_runtime.py','run_loss_calibration.py','launch_loss_calibration.py'):
    target=ROOT/'src'/name
    assert not target.exists()
    shutil.copy2(WS/'work'/name,target)
for stage,timeout in [('calibrate',180),('short',300),('full',600)]:
    if stage=='full' and not json.loads((ROOT/'short-summary.json').read_text())['pass']:
        print('FULL_SKIPPED_SHORT_GATE_FAILED',flush=True);break
    command=[sys.executable,'-u',str(ROOT/'src/run_loss_calibration.py'),stage]
    tick=time.monotonic()
    with (ROOT/f'{stage}.log').open('x') as log:
        try:
            code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            code=124
    record={'stage':stage,'exit_code':code,'elapsed_seconds':time.monotonic()-tick,'command':command,
            'LD_LIBRARY_PATH':os.environ.get('LD_LIBRARY_PATH'),'CONDA_PREFIX':os.environ.get('CONDA_PREFIX')}
    (ROOT/f'{stage}.exit.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)
    if code:
        print((ROOT/f'{stage}.log').read_text()[-4500:]);sys.exit(code)
print('ALL_AUTHORIZED_STAGES_COMPLETE',flush=True)
