import hashlib
import json
from pathlib import Path
import platform
import shutil
import sys
import tarfile
import torch
import dgl
import torch_geometric
from torch_geometric.datasets import Planetoid

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
OUT=WS/'outputs/reproduction-audit-20261102'
OUT.mkdir(exist_ok=False);(OUT/'src').mkdir()
BASE=WS/'outputs/fairness-recheck-20261101/official-loss-models'
experiment=Path('/mnt/d/cgt-experiment')
profiles={'p3':experiment/'reproduction-paper-similarity-20261102-01','p5':experiment/'reproduction-paper-p5-20261102-01'}
evaluation=experiment/'reproduction-final-evaluation-20261102-01'
assert json.loads((evaluation/'evaluation.exit.json').read_text())['exit_code']==0
shutil.copy2(profiles['p3']/'src/aligned_models.py',OUT/'src/aligned_models.py')
shutil.copy2(WS/'outputs/fairness-recheck-20261101/fairness_metrics.py',OUT/'src/fairness_metrics.py')
shutil.copy2(WS/'work/predict_reproduction_model.py',OUT/'src/predict_reproduction_model.py')
shutil.copy2(WS/'work/predict_reproduction.ps1',OUT/'predict.ps1')
shutil.copy2(profiles['p3']/'B-and-phi.pt',OUT/'cache-for-inference.pt')
for profile,folder in profiles.items():
    source_dest=OUT/'training-profiles'/profile
    source_dest.mkdir(parents=True,exist_ok=False)
    for path in (folder/'src').glob('*.py'):
        shutil.copy2(path,source_dest/path.name)
    shutil.copy2(folder/'protocol.json',source_dest/'protocol.json')
    for seed in range(3):
        destination=OUT/'models'/profile/f'seed-{seed:02d}'
        destination.mkdir(parents=True,exist_ok=False)
        for name in ('classifier-best.pt','pretrained.pt','validation-only.npz','result.json'):
            shutil.copy2(folder/f'full/seed-{seed:02d}'/name,destination/name)
(OUT/'locked-predictions').mkdir()
for path in (evaluation/'predictions').glob('*.npz'):
    shutil.copy2(path,OUT/'locked-predictions'/path.name)
for name in ('result.json','test-plan.json','checkpoint-lock.json','evaluation.log','evaluation.exit.json'):
    shutil.copy2(evaluation/name,OUT/name)

roots={
 'classifier-loss':experiment/'reproduction-classifier-loss-20261102-01',
 'independent-qk':experiment/'reproduction-independent-qk-20261102-01',
 'order-invariant':experiment/'reproduction-order-invariant-20261102-01',
 'paper-context':experiment/'reproduction-paper-context-20261102-01',
 'paper-similarity':profiles['p3'],'p5':profiles['p5'],
 'frozen-encoder':experiment/'reproduction-frozen-encoder-20261102-01',
 'cache-audit':experiment/'reproduction-cache-audit-20261102-02',
 'attention-audit':experiment/'reproduction-attention-audit-20261102-01',
 'metric-scope-audit':experiment/'reproduction-metric-scope-audit-20261102-02',
 'repo-order-fix':experiment/'reproduction-repo-order-fix-20261102-01'}
for name,folder in roots.items():
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in ('.py','.json','.jsonl','.log','.npz','.patch','.txt','.before'):
            destination=OUT/'evidence'/name/path.relative_to(folder)
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(path,destination)

data_root=Path('/root/cgt/repo/original_datasets/planetoid')
assert (data_root/'cora/processed/data.pt').is_file()
data=Planetoid(root=str(data_root),name='cora',split='public')[0]
dependencies={'dataset_root':str(data_root),
 'dataset_name':'cora',
 'graph_edge_index_sha256':hashlib.sha256(data.edge_index.numpy().tobytes()).hexdigest(),
 'features_sha256':hashlib.sha256(data.x.numpy().tobytes()).hexdigest(),
 'labels_sha256':hashlib.sha256(data.y.numpy().tobytes()).hexdigest(),
 'inference_cache_sha256':hashlib.sha256((OUT/'cache-for-inference.pt').read_bytes()).hexdigest(),
 'training_shared_source':str(BASE/'src/train_cora.py'),
 'training_shared_source_sha256':hashlib.sha256((BASE/'src/train_cora.py').read_bytes()).hexdigest(),
 'training_shared_architecture':str(BASE/'src/aligned_models.py'),
 'training_shared_architecture_sha256':hashlib.sha256((BASE/'src/aligned_models.py').read_bytes()).hexdigest(),
 'training_base_cache':str(BASE/'cora_k3_clusters5_official_rules.pt'),
 'training_base_cache_sha256':hashlib.sha256((BASE/'cora_k3_clusters5_official_rules.pt').read_bytes()).hexdigest(),
 'training_p5_targets':str(profiles['p5']/'logM-p5.pt'),
 'training_p5_targets_sha256':hashlib.sha256((profiles['p5']/'logM-p5.pt').read_bytes()).hexdigest(),
 'reference_training_roots':{k:str(v) for k,v in profiles.items()},
 'inference_requires_only_delivered_weights_cache_source_and_existing_Cora_dataset':True}
(OUT/'dependencies.json').write_text(json.dumps(dependencies,indent=2))
environment={'python':sys.version,'torch':torch.__version__,'dgl':dgl.__version__,
             'torch_geometric':torch_geometric.__version__,'cuda_runtime':torch.version.cuda,
             'gpu':torch.cuda.get_device_name(0),'platform':platform.platform(),
             'wsl_distribution':'Ubuntu-D','conda_prefix':'/root/miniconda3/envs/cgt',
             'LD_LIBRARY_PATH':'/root/miniconda3/envs/cgt/lib'}
(OUT/'environment.json').write_text(json.dumps(environment,indent=2))
source_archive=WS/'work/degfairgt-arxiv-source.tar'
with tarfile.open(source_archive) as archive:
    members=[{'name':m.name,'size':m.size} for m in archive.getmembers() if m.isfile()]
source_audit={'url':'https://arxiv.org/src/2504.15075','archive_sha256':hashlib.sha256(source_archive.read_bytes()).hexdigest(),
 'files':members,'file_count':len(members),
 'runtime_training_or_evaluation_scripts_found':any(Path(m['name']).suffix in ('.py','.ipynb','.sh') for m in members),
 'checkpoint_or_prediction_files_found':any(Path(m['name']).suffix in ('.pt','.pth','.npz','.csv') for m in members),
 'README_and_changelog_are_IEEEtran_template_materials':True,
 'source_text_retains_test_set_scope_and_per_class_absolute_EO_formula':True,
 'document_instructions_executed':False}
(OUT/'author-source-archive-audit.json').write_text(json.dumps(source_audit,indent=2))
shutil.copy2(Path(__file__),OUT/'src'/Path(__file__).name)
print(json.dumps({'out':str(OUT),'model_profiles':list(profiles),'status':'assembled'},indent=2))
