import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import numpy as np
import networkx as nx

repo=Path('/root/cgt/repo')
target=repo/'util.py'
root=Path('/mnt/d/cgt-experiment/reproduction-repo-order-fix-20261102-01')
root.mkdir(exist_ok=False)
source=target.read_text()
old='            if trans_check[src, dst] > 0.001:'
new='            if trans_check[src, dst] > 0.001 or trans_check[dst, src] > 0.001:'
assert source.count(old)==1 and new not in source
updated=source.replace(old,new)
compile(updated,str(target),'exec')
shutil.copy2(target,root/'util.py.before')
(root/'git-diff.before.patch').write_bytes(subprocess.check_output(['git','-C',str(repo),'diff','--binary']))
(root/'git-status.before.txt').write_bytes(subprocess.check_output(['git','-C',str(repo),'status','--short']))
(root/'candidate-order-only.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),updated.splitlines(True),
                                                    fromfile='a/util.py',tofile='b/util.py')))

class OneCommunity:
    def __init__(self,*args,**kwargs): pass
    def fit_predict(self,features): return np.zeros(len(features),dtype=np.int64)

def implementation(text):
    functions=[n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name in ('get_distance','get_B_sim_phi')]
    namespace={'np':np,'KMeans':OneCommunity,'compute_sim':lambda matrices,num_nodes,k_step:np.zeros((num_nodes,num_nodes,k_step))}
    exec(compile(ast.Module(body=functions,type_ignores=[]),'isolated-public-candidate-filter','exec'),namespace)
    return namespace['get_B_sim_phi']

graph=nx.path_graph(4)
adj=nx.to_numpy_array(graph)
transition=adj/adj.sum(1,keepdims=True)
third=np.zeros((4,4));third[0,2]=.0009;third[2,0]=.0012
matrices=[transition,transition@transition,third]
permutation=np.arange(4)[::-1]
permuted_graph=nx.Graph()
permuted_graph.add_nodes_from(range(4))
permuted_graph.add_edges_from((int(permutation[a]),int(permutation[b])) for a,b in graph.edges())
test={}
for name,text in [('before',source),('after',updated)]:
    fn=implementation(text)
    B,_,phi=fn(graph,matrices,4,1,np.zeros((4,1)),kstep=3)
    permuted=[m[permutation][:,permutation] for m in matrices]
    other,_,other_phi=fn(permuted_graph,permuted,4,1,np.zeros((4,1)),kstep=3)
    restored=other[permutation][:,permutation]
    restored_phi=other_phi[permutation][:,permutation]
    test[name]={'B_entries_changed_after_relabel':int(np.count_nonzero(B!=restored)),
                'phi_entries_changed_after_relabel':int(np.count_nonzero(phi!=restored_phi)),
                'target_pair_weight':float(B[0,2])}
assert test['before']['B_entries_changed_after_relabel']==2
assert test['after']['B_entries_changed_after_relabel']==0
assert test['after']['phi_entries_changed_after_relabel']==0
assert abs(test['after']['target_pair_weight']-1/np.sqrt(2))<1e-12
test['scope']='real public filter AST; community and similarity mocked to isolate asymmetric-threshold filtering. Separate full-Cora audit showed1342 unordered pairs changed under reverse numbering.'
temporary=target.with_name('util.py.pending-candidate-order-fix')
assert not temporary.exists()
with temporary.open('x') as stream: stream.write(updated)
shutil.copymode(target,temporary)
temporary.replace(target)
check=subprocess.run(['git','-C',str(repo),'diff','--check'],capture_output=True,text=True)
record={'file':str(target),'only_changed_line':'accept threshold if either direction passes',
        'before_sha256':hashlib.sha256(source.encode()).hexdigest(),'after_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'tests':test,'git_diff_check_exit_code':check.returncode,'git_diff_check_output':check.stdout+check.stderr,
        'historical_caches_modified':False}
(root/'fix-verification.json').write_text(json.dumps(record,indent=2))
(root/'git-status.after.txt').write_bytes(subprocess.check_output(['git','-C',str(repo),'status','--short']))
assert check.returncode==0
print(json.dumps(record,indent=2))
