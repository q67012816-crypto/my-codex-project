import hashlib
import json
from pathlib import Path
import shutil
import subprocess

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
OUT=WS/'outputs/reproduction-audit-20261102'
EXPERIMENT=Path('/mnt/d/cgt-experiment')
names=['reproduction-classifier-loss-20261102-01','reproduction-independent-qk-20261102-01',
       'reproduction-order-invariant-20261102-01','reproduction-paper-context-20261102-01',
       'reproduction-paper-similarity-20261102-01','reproduction-paper-p5-20261102-01']
exits=[]
for name in names:
    for stage in ('smoke','full'):
        record=json.loads((EXPERIMENT/name/f'{stage}.exit.json').read_text())
        assert record['exit_code']==0
        exits.append({'experiment':name,'stage':stage,**record})
(OUT/'process-exit-summary.json').write_text(json.dumps(exits,indent=2))
dependencies=json.loads((OUT/'dependencies.json').read_text())
verification=[]
for entry in json.loads((OUT/'checkpoint-lock.json').read_text()):
    path=OUT/'models'/entry['profile']/f"seed-{entry['seed']:02d}/classifier-best.pt"
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest==entry['sha256']
    verification.append({'path':str(path.relative_to(OUT)),'matches_locked_classifier_sha256':True})
    pretrained=path.with_name('pretrained.pt')
    original=Path(dependencies['reference_training_roots'][entry['profile']])/f"full/seed-{entry['seed']:02d}/pretrained.pt"
    assert hashlib.sha256(pretrained.read_bytes()).hexdigest()==hashlib.sha256(original.read_bytes()).hexdigest()
assert hashlib.sha256((OUT/'cache-for-inference.pt').read_bytes()).hexdigest()==dependencies['inference_cache_sha256']
for path in (OUT/'verification').glob('*/result.json'):
    data=json.loads(path.read_text())
    if 'all_node_predictions_identical_to_locked_evaluation' in data:
        assert data['all_node_predictions_identical_to_locked_evaluation']
for name in ('build_replication_delivery.py','finalize_replication_delivery.py','verify_retraining_predictions.py',
             'audit_raw_graph_counts.py','audit_metric_scope.py','fix_public_candidate_order.py'):
    shutil.copy2(WS/'work'/name,OUT/'src'/name)
shutil.copy2(WS/'outputs/fairness-recheck-20261101/LICENSE.official',OUT/'LICENSE.official')
check=subprocess.run(['git','-C','/root/cgt/repo','diff','--check'],capture_output=True,text=True)
assert check.returncode==0
result=json.loads((OUT/'result.json').read_text())
assert result['primary_triage_passed'] is False
(OUT/'delivery-verification.json').write_text(json.dumps({'classifiers':verification,
 'pretrained_files_match_executed_recipes':True,'inference_cache_sha256_matches':True,
 'git_diff_check_exit_code':0,'paper_fairness_goal_achieved':False,
 'status':'integrity_passed_performance_target_not_met'},indent=2))
manifest=[{'path':str(p.relative_to(OUT)),'size':p.stat().st_size,
           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='manifest.json']
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'out':str(OUT),'files':len(manifest)+1,'total_bytes':sum(r['size'] for r in manifest),
                  'verified_classifiers':len(verification),'paper_fairness_goal_achieved':False},indent=2))
