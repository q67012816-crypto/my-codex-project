import collections
import hashlib
import json
from pathlib import Path
import pickle
import numpy as np

class DataOnlyUnpickler(pickle.Unpickler):
    def find_class(self,module,name):
        if (module,name)==('collections','defaultdict'):return collections.defaultdict
        if module in ('builtins','__builtin__') and name=='list':return list
        raise pickle.UnpicklingError('Unexpected class in raw graph data')

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
OUT=WS/'outputs/reproduction-audit-20261102'
path=Path('/root/cgt/repo/original_datasets/planetoid/cora/raw/ind.cora.graph')
with path.open('rb') as stream: raw=DataOnlyUnpickler(stream,encoding='latin1').load()
assert isinstance(raw,dict)
entries=[(int(a),int(b)) for a,neighbors in raw.items() for b in neighbors]
assert all(0<=a<2708 and 0<=b<2708 for a,b in entries)
simple={(a,b) for a,b in entries if a!=b}
undirected={tuple(sorted((a,b))) for a,b in simple}
values=np.load(OUT/'locked-predictions/p3-seed-00.npz')
processed=set(map(tuple,values['edge_index'].T.tolist()))
record={'raw_graph_path':str(path),'raw_graph_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'raw_adjacency_entries_with_duplicates':len(entries),
 'half_raw_entries':len(entries)/2,'raw_self_loop_entries':sum(a==b for a,b in entries),
 'unique_directed_nonself_edges':len(simple),'unique_undirected_nonself_edges':len(undirected),
 'processed_directed_entries':len(processed),'raw_simple_graph_equals_processed_graph':simple==processed,
 'paper_reported_Cora_edges':5429,
 'interpretation':'the common5429 count equals half raw adjacency entries, while public PyG preprocessing removes duplicate arcs and yields5278 simple undirected edges; no edges were invented to match a table count'}
assert simple==processed and len(undirected)==5278 and len(entries)/2==5429
(OUT/'data-preprocessing-audit.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
