import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import torch
WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
OUT=WS/'outputs/reproduction-audit-20261102'
BASE=WS/'outputs/fairness-recheck-20261101/official-loss-models'
run=Path('/mnt/d/cgt-experiment/replay-p3-train-8f7e7232')
sys.path.insert(0,str(BASE/'src'))
spec=importlib.util.spec_from_file_location('aligned_models',OUT/'src/aligned_models.py')
architecture=importlib.util.module_from_spec(spec);sys.modules['aligned_models']=architecture;spec.loader.exec_module(architecture)
import train_cora as training
sys.path.insert(0,str(OUT/'src'))
from fairness_metrics import evaluate,generalized_degree
data,graph,adjacency,cache_cpu,g=training.load_inputs()
cache_cpu.update(torch.load(OUT/'cache-for-inference.pt',map_location='cpu'))
cache={k:v.to(training.DEVICE) if isinstance(v,torch.Tensor) else v for k,v in cache_cpu.items() if k not in ('M','community_labels')}
checkpoint=torch.load(run/'full/seed-00/classifier-best.pt',map_location='cpu')
model=training.Classifier(training.model_new()).to(training.DEVICE);model.load_state_dict(checkpoint['state_dict'])
logits=training.evaluate(model,(data,graph,adjacency,cache,g),checkpoint['best_epoch'],checkpoint['evaluation_seed'])
prediction=logits.argmax(1).cpu().numpy()
reference=np.load(OUT/'locked-predictions/p3-seed-00.npz')
degree=generalized_degree(data.edge_index.numpy(),data.num_nodes,1)
record={'replay_run':str(run),'best_epoch':checkpoint['best_epoch'],'splits':{}}
for scope,ids in [('all_nodes',np.arange(data.num_nodes)),('val',reference['val_ids']),('test',reference['test_ids'])]:
    metric=evaluate(prediction,data.y.numpy(),degree,ids,.2,'reference_percentile')
    record['splits'][scope]={'predictions_changed':int(np.sum(prediction[ids]!=reference['predictions_single'][ids])),
                            'accuracy':100*float(np.mean(prediction[ids]==data.y.numpy()[ids])),
                            'SP':metric['SP'],'EO':metric['EO_strict']}
assert record['splits']['val']['predictions_changed']==0
(OUT/'verification/retraining-full-predictions.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
