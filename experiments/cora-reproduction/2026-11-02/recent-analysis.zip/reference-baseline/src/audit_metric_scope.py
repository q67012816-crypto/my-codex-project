import hashlib
import json
from pathlib import Path
import sys
import numpy as np

WS=Path('/mnt/d/Codex/documents/2026-11-01/windows-wsl2-cgt-degfairgt-cora-10')
sys.path.insert(0,str(WS/'outputs/fairness-recheck-20261101'))
from fairness_metrics import evaluate,generalized_degree
root=Path('/mnt/d/cgt-experiment/reproduction-metric-scope-audit-20261102-02')
root.mkdir(exist_ok=False)
folders={'old10':WS/'outputs/cora-trained-models','corrected_official_mean3':WS/'outputs/fairness-recheck-20261101/official-loss-models'}
results=[]
for group,folder in folders.items():
    files=sorted(folder.rglob('predictions-and-split.npz'))
    files=[p for p in files if p.parent.name.startswith('seed-') and 'src' not in p.parts]
    assert len(files)==(10 if group=='old10' else 3)
    for path in files:
        values=np.load(path)
        degree=generalized_degree(values['edge_index'],len(values['labels']),1)
        row={'group':group,'model':path.parent.name,'prediction_archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scopes':{}}
        for scope,ids in [('train',values['train_ids']),('validation',values['val_ids']),('test_already_observed',values['test_ids']),('all_nodes_includes_training',np.arange(len(degree)))]:
            metric=evaluate(values['predictions'],values['labels'],degree,ids,.2,'reference_percentile')
            signed=[c['low_recall']-c['high_recall'] for c in metric['per_class'] if c['recall_gap'] is not None]
            row['scopes'][scope]={'accuracy':100*float(np.mean(values['predictions'][ids]==values['labels'][ids])),
                  'SP':metric['SP'],'EO':metric['EO_strict'],'low_n':metric['low_n'],'high_n':metric['high_n'],
                  'absolute_difference_of_macro_recalls_NOT_EO':100*float(abs(np.mean(signed))),
                  'missing_classes':metric['missing_classes']}
        results.append(row)
summary={}
for group in folders:
    subset=[r for r in results if r['group']==group]
    if not subset:continue
    summary[group]={scope:{key:{'mean':float(np.mean([r['scopes'][scope][key] for r in subset])),
                                   'std_population':float(np.std([r['scopes'][scope][key] for r in subset]))}
                             for key in ('accuracy','SP','EO','absolute_difference_of_macro_recalls_NOT_EO')}
                    for scope in subset[0]['scopes']}
record={'scope':'read-only audit using historical already-observed predictions, no model or hyperparameter selection',
 'revision':'exclude smoke from all cohorts; v1 corrected-official-mean cohort included smoke and is superseded',
 'primary_EO_definition_unchanged':True,
 'warning':'all-node scores include training nodes; absolute macro-recall difference cancels class gaps and is NOT the paper EO; neither is accepted as a reproduction fix',
 'results':results,'summary':summary}
(root/'scope-audit.json').write_text(json.dumps(record,indent=2))
print(json.dumps(summary,indent=2))
