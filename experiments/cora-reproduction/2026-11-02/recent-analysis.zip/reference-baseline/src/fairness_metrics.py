"""Degree fairness: A^r 1; explicit rank and source-percentile protocols."""
import numpy as np
import scipy.sparse as sp

def generalized_degree(edge_index, n_nodes, radius):
    if radius < 1 or int(radius) != radius:
        raise ValueError('radius must be a positive integer')
    adjacency = sp.csr_matrix((np.ones(edge_index.shape[1]), (edge_index[0], edge_index[1])),
                               shape=(n_nodes, n_nodes))
    adjacency.data[:] = 1  # Unweighted simple graph, independently of duplicate input edges.
    degree = np.ones(n_nodes)
    for _ in range(radius):
        degree = adjacency @ degree
    return degree

def evaluate(prediction, truth, degree, ids, ratio=0.2, protocol='exact_rank'):
    if not 0 < ratio < .5:
        raise ValueError('ratio must lie between 0 and 0.5')
    if protocol == 'exact_rank':
        count = int(len(ids)*ratio)
        order = np.lexsort((ids, degree[ids]))
        low, high = ids[order[:count]], ids[order[-count:]]
        thresholds = None
    elif protocol == 'reference_percentile':
        thresholds = np.percentile(degree[ids], [100*ratio, 100*(1-ratio)])
        low, high = ids[degree[ids] <= thresholds[0]], ids[degree[ids] > thresholds[1]]
        thresholds = thresholds.tolist()
    else:
        raise ValueError(protocol)
    if not len(low) or not len(high):
        raise ValueError('Grouping produced an empty group')
    classes = np.unique(truth[ids])
    sp_values, eo_values, missing, detail = [], [], [], []
    for c in classes:
        sp_values.append(abs(np.mean(prediction[low] == c)-np.mean(prediction[high] == c)))
        a, b = low[truth[low] == c], high[truth[high] == c]
        if len(a) and len(b):
            lo, hi = float(np.mean(prediction[a] == c)), float(np.mean(prediction[b] == c))
            difference = abs(lo-hi)
        else:
            lo = hi = difference = None
            missing.append(int(c))
        eo_values.append(0.0 if difference is None else difference)
        detail.append({'class': int(c), 'low_n': len(a), 'high_n': len(b),
                       'low_recall': lo, 'high_recall': hi, 'recall_gap': difference})
    return {'protocol': protocol, 'ratio': ratio, 'thresholds': thresholds,
            'SP': 100*float(np.mean(sp_values)),
            'EO_strict': None if missing else 100*float(np.mean(eo_values)),
            'EO_reference_zero_missing': 100*float(np.mean(eo_values)),
            'missing_classes': missing, 'per_class': detail,
            'low_n': len(low), 'high_n': len(high), 'low_ids': low.tolist(), 'high_ids': high.tolist(),
            'low_accuracy': 100*float(np.mean(prediction[low] == truth[low])),
            'high_accuracy': 100*float(np.mean(prediction[high] == truth[high]))}
