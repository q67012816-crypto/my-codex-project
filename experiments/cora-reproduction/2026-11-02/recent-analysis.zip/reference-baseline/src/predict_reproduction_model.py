"""Reload a delivered Cora checkpoint with the exact frozen inference cache."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import uuid
import numpy as np
import torch
import dgl
from torch_geometric.datasets import Planetoid

parser=argparse.ArgumentParser()
parser.add_argument('--artifact-root',type=Path,default=Path(__file__).resolve().parent.parent)
parser.add_argument('--profile',choices=['p3','p5'],default='p3')
parser.add_argument('--seed',type=int,choices=[0,1,2],default=0)
parser.add_argument('--split',choices=['val','test'],default='val')
parser.add_argument('--draws',type=int,choices=[1,8],default=1)
args=parser.parse_args()
ROOT=args.artifact_root
sys.path.insert(0,str(ROOT/'src'))
from fairness_metrics import evaluate,generalized_degree
spec=importlib.util.spec_from_file_location('delivered_architecture',ROOT/'src/aligned_models.py')
architecture=importlib.util.module_from_spec(spec);spec.loader.exec_module(architecture)
torch.set_num_threads(4)
torch.backends.cudnn.benchmark=False
torch.backends.cudnn.deterministic=True
assert torch.cuda.is_available(),'Use the recorded WSL cgt environment and CUDA driver.'
DEVICE=torch.device('cuda:0')
metadata=json.loads((ROOT/'dependencies.json').read_text())
data_root=Path(metadata['dataset_root'])
assert data_root.is_dir()
dataset_name=metadata.get('dataset_name','cora')
assert (data_root/dataset_name/'processed/data.pt').is_file(),'Reuse the existing processed dataset.'
data=Planetoid(root=str(data_root),name=dataset_name,split='public')[0]
assert hashlib.sha256(data.edge_index.numpy().tobytes()).hexdigest()==metadata['graph_edge_index_sha256']
assert hashlib.sha256(data.x.numpy().tobytes()).hexdigest()==metadata['features_sha256']
cache_path=ROOT/'cache-for-inference.pt'
assert hashlib.sha256(cache_path.read_bytes()).hexdigest()==metadata['inference_cache_sha256']
cache={k:v.to(DEVICE) for k,v in torch.load(cache_path,map_location='cpu').items()}
adjacency=torch.zeros(data.num_nodes,data.num_nodes,device=DEVICE)
adjacency[data.edge_index[0],data.edge_index[1]]=1
g=dgl.graph((data.edge_index[0],data.edge_index[1]),num_nodes=data.num_nodes).to(DEVICE)
g.ndata['x']=data.x.to(DEVICE)

class Classifier(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder=architecture.Transformer(1433,64,7,hidden_dim=64,num_layers=4,num_heads=4,k_transition=3,
             aug_check=1,sim_check=1,phi_check=1,alfa=.2,beta=.8,dropout=.1).to(DEVICE)
        self.head=architecture.MLP(64,7)
    def forward(self,epoch):
        features=g.ndata['x']
        h,_=self.encoder.extract_features(g,adjacency,features,epoch,torch.stack(g.edges()),
               cache['sim'],cache['phi'],cache['B'],3,DEVICE,DEVICE)
        return self.head(h)

checkpoint_path=ROOT/'models'/args.profile/f'seed-{args.seed:02d}/classifier-best.pt'
checkpoint_sha=hashlib.sha256(checkpoint_path.read_bytes()).hexdigest()
checkpoint=torch.load(checkpoint_path,map_location='cpu')
model=Classifier().to(DEVICE);model.load_state_dict(checkpoint['state_dict']);model.eval()
probabilities=[]
with torch.no_grad():
    for draw in range(args.draws):
        with torch.random.fork_rng(devices=[0]):
            torch.manual_seed(checkpoint['evaluation_seed']+1000000*draw)
            torch.cuda.manual_seed_all(checkpoint['evaluation_seed']+1000000*draw)
            logits=model(checkpoint['best_epoch'])
        probabilities.append(logits.softmax(1).cpu().numpy())
prediction=np.mean(probabilities,axis=0).argmax(1)
ids=checkpoint['split'][args.split].numpy()
truth=data.y.numpy()
degree=generalized_degree(data.edge_index.numpy(),data.num_nodes,1)
metric=evaluate(prediction,truth,degree,ids,.2,'reference_percentile')
assert not metric['missing_classes']
reference=np.load(ROOT/'locked-predictions'/f'{args.profile}-seed-{args.seed:02d}.npz')
expected=reference['predictions_single' if args.draws==1 else 'predictions_mean8']
assert np.array_equal(prediction,expected),'Prediction differed from the locked evaluation.'
result={'profile':args.profile,'seed':args.seed,'split':args.split,'draws':args.draws,
        'accuracy':100*float(np.mean(prediction[ids]==truth[ids])),'SP':metric['SP'],'EO':metric['EO_strict'],
        'per_class':metric['per_class'],'checkpoint_sha256':checkpoint_sha,
        'all_node_predictions_identical_to_locked_evaluation':True,
        'test_metrics_computed':args.split=='test'}
dest=ROOT/'verification'/f'{args.profile}-seed-{args.seed:02d}-{args.split}-{args.draws}draw-{uuid.uuid4().hex[:8]}'
dest.mkdir(parents=True,exist_ok=False)
(dest/'result.json').write_text(json.dumps(result,indent=2))
np.savez_compressed(dest/'predictions.npz',node_ids=ids,labels=truth[ids],prediction=prediction[ids],degree=degree[ids])
print(json.dumps(result,indent=2))
print('SAVED '+str(dest))
