"""Replay an archived training recipe in a fresh D-drive run directory."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

parser=argparse.ArgumentParser()
parser.add_argument('--artifact-root',type=Path,default=Path(__file__).resolve().parent.parent)
parser.add_argument('--profile',choices=['p3','p5'],default='p3')
parser.add_argument('--mode',choices=['smoke','train'],default='smoke')
parser.add_argument('--seeds',default='0,1,2')
args=parser.parse_args()
seeds=list(map(int,args.seeds.split(',')))
assert seeds and len(set(seeds))==len(seeds) and all(seed in (0,1,2) for seed in seeds)
OUT=args.artifact_root
dependency=json.loads((OUT/'dependencies.json').read_text())
for pathkey,shakey in [('training_shared_source','training_shared_source_sha256'),
                       ('training_shared_architecture','training_shared_architecture_sha256'),
                       ('training_base_cache','training_base_cache_sha256')]:
    path=Path(dependency[pathkey])
    assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==dependency[shakey],path
root=Path('/mnt/d/cgt-experiment')/f"replay-{args.profile}-{args.mode}-{uuid.uuid4().hex[:8]}"
root.mkdir(exist_ok=False);(root/'src').mkdir()
source_folder=OUT/'training-profiles'/args.profile
shutil.copy2(source_folder/'aligned_models.py',root/'src/aligned_models.py')
source=(source_folder/'reproduce_independent_qk.py').read_text()
original_sha=hashlib.sha256(source.encode()).hexdigest()
old="parser.add_argument('--smoke',action='store_true')"
assert source.count(old)==1
source=source.replace(old,old+"\nparser.add_argument('--seed-list',default='0,1,2')")
old_loop="for seed in ([0] if args.smoke else [0,1,2]):"
assert source.count(old_loop)==1
source=source.replace(old_loop,"for seed in ([0] if args.smoke else list(map(int,args.seed_list.split(',')))):")
cache_path=OUT/'cache-for-inference.pt'
assert hashlib.sha256(cache_path.read_bytes()).hexdigest()==dependency['inference_cache_sha256']
def link_or_copy(source,destination):
    assert not destination.exists()
    try: os.link(source,destination)
    except OSError: shutil.copy2(source,destination)
link_or_copy(cache_path,root/'B-and-phi.pt')
if args.profile=='p5':
    target=Path(dependency['training_p5_targets'])
    assert hashlib.sha256(target.read_bytes()).hexdigest()==dependency['training_p5_targets_sha256']
    link_or_copy(target,root/'logM-p5.pt')
    old_cache_literal="Path('/mnt/d/cgt-experiment/reproduction-paper-similarity-20261102-01/B-and-phi.pt')"
    assert source.count(old_cache_literal)==1
    source=source.replace(old_cache_literal,"Path("+repr(str(cache_path))+")")
compile(source,'reproduce_independent_qk.py','exec')
(root/'src/reproduce_independent_qk.py').write_text(source)
shutil.copy2(source_folder/'protocol.json',root/'protocol.json')
run_metadata={'profile':args.profile,'mode':args.mode,'seeds':[0] if args.mode=='smoke' else seeds,
              'executed_recipe_sha256_before_adapter':original_sha,
              'adapter_changes':['fresh output location','seed-list CLI only','equivalent cache path for p5'],
              'numerical_training_code_changed':False}
(root/'replay-plan.json').write_text(json.dumps(run_metadata,indent=2))
command=[sys.executable,'-u',str(root/'src/reproduce_independent_qk.py'),'--seed-list',args.seeds]
if args.mode=='smoke':command.append('--smoke')
start=time.monotonic()
with (root/'run.log').open('x') as log:
    code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1200).returncode
record={**run_metadata,'run_root':str(root),'exit_code':code,'elapsed_seconds':time.monotonic()-start}
(root/'run.exit.json').write_text(json.dumps(record,indent=2))
verification=OUT/'verification'/root.name
verification.mkdir(parents=True,exist_ok=False)
shutil.copy2(root/'run.exit.json',verification/'run.exit.json')
shutil.copy2(root/'replay-plan.json',verification/'replay-plan.json')
if code:
    print((root/'run.log').read_text()[-5000:])
    sys.exit(code)
import numpy as np
import torch
checks=[]
for seed in ([0] if args.mode=='smoke' else seeds):
    actual=root/('smoke' if args.mode=='smoke' else 'full')/f'seed-{seed:02d}'
    reference=(OUT/'evidence'/('paper-similarity' if args.profile=='p3' else 'p5')/'smoke'/f'seed-{seed:02d}'
               if args.mode=='smoke' else OUT/'models'/args.profile/f'seed-{seed:02d}')
    expected=np.load(reference/'validation-only.npz')
    observed=np.load(actual/'validation-only.npz')
    identical=bool(np.array_equal(expected['predictions'],observed['predictions']))
    assert np.array_equal(expected['validation_ids'],observed['validation_ids'])
    check={'seed':seed,'validation_predictions_identical_to_original_recipe':identical}
    if args.mode=='train':
        old=torch.load(reference/'classifier-best.pt',map_location='cpu')['state_dict']
        new=torch.load(actual/'classifier-best.pt',map_location='cpu')['state_dict']
        check['max_abs_state_difference']=max(float((new[k]-v).abs().max()) for k,v in old.items())
    checks.append(check)
    shutil.copy2(actual/'result.json',verification/f'seed-{seed:02d}-result.json')
    assert identical,'Replay validation predictions differed; inspect recorded results.'
record['checks']=checks
(verification/'verification.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
